/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50525
Source Host           : localhost:3306
Source Database       : crm

Target Server Type    : MYSQL
Target Server Version : 50525
File Encoding         : 65001

Date: 2018-04-03 20:57:18
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `t_permission`
-- ----------------------------
DROP TABLE IF EXISTS `t_permission`;
CREATE TABLE `t_permission` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `resource` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_permission
-- ----------------------------
INSERT INTO `t_permission` VALUES ('1', '部门列表', '/department/list', 'department:list');
INSERT INTO `t_permission` VALUES ('2', '部门保存', '/department/save', 'department:save');
INSERT INTO `t_permission` VALUES ('3', '部门删除', '/department/delete', 'department:delete');
INSERT INTO `t_permission` VALUES ('4', '员工列表', '/employee/list', 'employee:list');
INSERT INTO `t_permission` VALUES ('5', '员工保存', '/employee/save', 'employee:save');
INSERT INTO `t_permission` VALUES ('6', '员工删除', '/employee/delete', 'employee:delete');
INSERT INTO `t_permission` VALUES ('7', '角色列表', '/role/list', 'role:list');
INSERT INTO `t_permission` VALUES ('8', '角色保存', '/role/save', 'role:save');
INSERT INTO `t_permission` VALUES ('9', '角色刪除', '/role/delete', 'role:delete');
INSERT INTO `t_permission` VALUES ('10', '权限列表', '/permission/list', 'permission:list');
INSERT INTO `t_permission` VALUES ('11', '权限保存', '/permission/save', 'permission:save');
INSERT INTO `t_permission` VALUES ('12', '权限删除', '/permission/delete', 'permission:delete');
INSERT INTO `t_permission` VALUES ('13', '菜单列表', '/menu/list', 'menu:list');
INSERT INTO `t_permission` VALUES ('14', '菜单保存', '/menu/save', 'menu:save');
INSERT INTO `t_permission` VALUES ('15', '菜单删除', '/menu/delete', 'menu:delete');
INSERT INTO `t_permission` VALUES ('16', '客户列表', '/customer/list', 'customer:list');
INSERT INTO `t_permission` VALUES ('17', '客户保存', '/customer/save', 'customer:save');
INSERT INTO `t_permission` VALUES ('18', '客户删除', '/customer/delete', 'customer:delete');
INSERT INTO `t_permission` VALUES ('19', '系统日志列表', '/systemLog/list', 'systemLog:list');
INSERT INTO `t_permission` VALUES ('20', '系统日志保存', '/systemLog/save', 'systemLog:save');
INSERT INTO `t_permission` VALUES ('21', '系统日志删除', '/systemLog/delete', 'systemLog:delete');

-- ----------------------------
-- Table structure for `t_role`
-- ----------------------------
DROP TABLE IF EXISTS `t_role`;
CREATE TABLE `t_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sn` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_role
-- ----------------------------
INSERT INTO `t_role` VALUES ('1', 'sn0', 'name0');
INSERT INTO `t_role` VALUES ('2', 'sn1', 'name1');
INSERT INTO `t_role` VALUES ('3', 'sn2', 'name2');
INSERT INTO `t_role` VALUES ('4', 'sn3', 'name3');
INSERT INTO `t_role` VALUES ('5', 'sn4', 'name4');
INSERT INTO `t_role` VALUES ('6', 'sn5', 'name5');
INSERT INTO `t_role` VALUES ('7', 'sn6', 'name6');
INSERT INTO `t_role` VALUES ('8', 'sn7', 'name7');
INSERT INTO `t_role` VALUES ('11', '23123', '1231');
INSERT INTO `t_role` VALUES ('17', '333333333', '333333333');
INSERT INTO `t_role` VALUES ('18', '4654654', '6541989');

-- ----------------------------
-- Table structure for `t_role_permission`
-- ----------------------------
DROP TABLE IF EXISTS `t_role_permission`;
CREATE TABLE `t_role_permission` (
  `role_id` bigint(20) NOT NULL,
  `permission_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_role_permission
-- ----------------------------
INSERT INTO `t_role_permission` VALUES ('1', '1');
INSERT INTO `t_role_permission` VALUES ('1', '2');
INSERT INTO `t_role_permission` VALUES ('1', '3');
INSERT INTO `t_role_permission` VALUES ('1', '4');
INSERT INTO `t_role_permission` VALUES ('1', '5');
INSERT INTO `t_role_permission` VALUES ('1', '6');
INSERT INTO `t_role_permission` VALUES ('1', '7');
INSERT INTO `t_role_permission` VALUES ('1', '8');
INSERT INTO `t_role_permission` VALUES ('1', '9');
INSERT INTO `t_role_permission` VALUES ('1', '10');
INSERT INTO `t_role_permission` VALUES ('1', '11');
INSERT INTO `t_role_permission` VALUES ('1', '13');
INSERT INTO `t_role_permission` VALUES ('1', '12');
INSERT INTO `t_role_permission` VALUES ('1', '14');
INSERT INTO `t_role_permission` VALUES ('1', '15');
INSERT INTO `t_role_permission` VALUES ('1', '16');
INSERT INTO `t_role_permission` VALUES ('1', '17');
INSERT INTO `t_role_permission` VALUES ('1', '19');
INSERT INTO `t_role_permission` VALUES ('1', '18');
INSERT INTO `t_role_permission` VALUES ('1', '20');
INSERT INTO `t_role_permission` VALUES ('1', '21');
INSERT INTO `t_role_permission` VALUES ('1', '22');
INSERT INTO `t_role_permission` VALUES ('2', '1');
INSERT INTO `t_role_permission` VALUES ('2', '2');
INSERT INTO `t_role_permission` VALUES ('2', '3');
INSERT INTO `t_role_permission` VALUES ('2', '4');
INSERT INTO `t_role_permission` VALUES ('3', '1');
INSERT INTO `t_role_permission` VALUES ('3', '3');
INSERT INTO `t_role_permission` VALUES ('3', '2');
INSERT INTO `t_role_permission` VALUES ('3', '4');
INSERT INTO `t_role_permission` VALUES ('20', '1');
INSERT INTO `t_role_permission` VALUES ('18', '3');
INSERT INTO `t_role_permission` VALUES ('18', '4');
INSERT INTO `t_role_permission` VALUES ('18', '6');
INSERT INTO `t_role_permission` VALUES ('18', '5');
INSERT INTO `t_role_permission` VALUES ('18', '8');
