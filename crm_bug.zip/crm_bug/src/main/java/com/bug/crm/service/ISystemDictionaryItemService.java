package com.bug.crm.service;

import com.bug.crm.domain.SystemDictionaryItem;

/**
 * 部门管理service层接口
 *
 */
public interface ISystemDictionaryItemService extends IBaseService<SystemDictionaryItem> {
	
}
