package com.bug.crm.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bug.crm.domain.Role;
import com.bug.crm.mapper.RoleMapper;
import com.bug.crm.service.IRoleService;

/**
 * 子类部门管理的service层实现,必须有@service注解
 *
 */
@Service
public class RoleServiceImpl extends BaseServiceImpl<Role> implements IRoleService {

	@Autowired
	RoleMapper roleMapper;

	// 自己实现级联删除、级联保存、级联修改的效果
	@Override
	@Transactional
	public void delete(Long id) {
		// 先删除中间表
		roleMapper.deleteRolePermission(id);
		// 在删除角色表
		roleMapper.delete(id);
	}

	@Override
	@Transactional
	public void save(Role role) {
		// 先保存角色，获取主键id
		roleMapper.save(role);
		// 再保存角色权限中间表
		//size大于0即有数据的时候才能保存，否则insert语句后面的values会没有值
		if (role.getPermissions().size() > 0) {
			roleMapper.saveRolePermission(role.getPermissionMap());
		}
	}

	@Override
	@Transactional
	public void update(Role role) {
		// 先删除角色权限中间表
		roleMapper.deleteRolePermission(role.getId());
		// 先修改角色
		roleMapper.update(role);
		// 再保存角色权限中间表
		// size大于0即有数据的时候才能保存，否则insert语句后面的values会没有值
		if (role.getPermissions().size() > 0) {
			roleMapper.saveRolePermission(role.getPermissionMap());
		}
	}
}
