package com.bug.crm.service;

import com.bug.crm.domain.WarrantyBillItem;

/**
 * 
 * @author leowan
 * 日期:2018年3月29日
 * 类描述:合同明细service层接口
 */
public interface IWarrantyBillItemService extends IBaseService<WarrantyBillItem> {
	
}
