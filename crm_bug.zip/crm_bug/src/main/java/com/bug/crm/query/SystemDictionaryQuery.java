package com.bug.crm.query;

public class SystemDictionaryQuery extends BaseQuery {
}
