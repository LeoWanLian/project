package com.bug.crm.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bug.crm.domain.Contract;
import com.bug.crm.domain.ContractItem;
import com.bug.crm.query.ContractItemQuery;
import com.bug.crm.query.ContractQuery;
import com.bug.crm.query.PageList;
import com.bug.crm.service.ICustomerService;
import com.bug.crm.service.IEmployeeService;
import com.bug.crm.service.IContractItemService;
import com.bug.crm.service.IContractService;
import com.bug.crm.util.AjaxResult;

/**
 * 定金订单控制层
 * 
 * @author leowan
 */
@Controller
@RequestMapping("/contract")
public class ContractController {
	@Autowired
	IContractService contractService;
	@Autowired
	ICustomerService customerService;
	@Autowired
	IEmployeeService employeeService;
	@Autowired
	IContractItemService contractItemService;

	// 一个方法显示页面,其他都返回json
	@RequestMapping("/list")
	public String list(Model model) {
		model.addAttribute("contracts", contractService.getAll());
		return "contract";
	}

	@RequestMapping("/json")
	@ResponseBody
	public PageList json(ContractQuery baseQuery) {
		return contractService.findByQuery(baseQuery);
	}

	// 保存方法
	@RequestMapping("/save")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult save(Contract contract) {
		if(contract.getFlag()!=null){
			contract.setId(null);
		}
		// 将前台传过来的合同ID封装到查询对象里面
		ContractItemQuery baseQuery = new ContractItemQuery();
		baseQuery.setContractId(contract.getId());
		// 通过前台传过来的合同ID,查到对应的合同明细.
		PageList findByQuery = contractItemService.findByQuery(baseQuery);
		// 数据库已存在的明细
		List<ContractItem> items3 = findByQuery.getRows();
		// 前台传过来的明细
		List<ContractItem> items = contract.getItems();
		if (items == null) {
			items = new ArrayList<ContractItem>();
		}
		try {
			if (contract.getId() != null) {//修改
				if("".equals(contract.getSn())||contract.getSn()==null){
					contract.setSn("sn-"+new SimpleDateFormat("yyyyMMddHHmmSSS").format(new Date()));
				}
				contractService.update(contract);
				// 遍历删除合同已有的明细
				for (ContractItem contractItem : items3) {
					contractItemService.delete(contractItem.getId());
				}
				// 再把前台传过来的明细保存到数据库
				for (ContractItem contractItem : items) {
					contractItem.setContract(contract);
					contractItemService.save(contractItem);
				}
			} else {//新增
				// 先保存一方合同
				contract.setSn("sn-"+new SimpleDateFormat("yyyyMMddHHmmSSS").format(new Date()));
				contractService.save(contract);
				// 再保存多方,明细
				for (ContractItem contractItem : items) {
					contractItem.setContract(contract);
					contractItemService.save(contractItem);
				}
			}
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("保存异常:" + e.getMessage());
		}
	}

	@RequestMapping("/delete")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult delete(String ids) {
		try {
			// 截取字符串
			String[] strArr = ids.split(",");
			// 将前台传过来的字符串转成long数组
			Long[] str2 = new Long[strArr.length];
			for (int i = 0; i < strArr.length; i++) {
				str2[i] = Long.valueOf(strArr[i]);
			}
			contractService.delete(str2);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}

	@RequestMapping("/getCustomerData")
	@ResponseBody
	// 下拉选择客户信息
	public Object getCustomerData() {
		return customerService.getAll();
	}

	@RequestMapping("/getSellerrData")
	@ResponseBody
	// 下拉选择销售人员信息
	public Object getSellerrData() {
		return employeeService.getAll();
	}

	@RequestMapping("/findItemsById")
	@ResponseBody
	// 根据合同Id查询对应的明细
	public PageList findItemsById(ContractItemQuery baseQuery) {
		// contractItemService.findByQuery(baseQuery));
		return contractItemService.findByQuery(baseQuery);
	}

}
