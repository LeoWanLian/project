package com.bug.crm.service;

import com.bug.crm.domain.CutomerTransfer;

/**
 * 客户信息管理
 * 
 * @author leowan
 */
public interface ICutomerTransferService extends IBaseService<CutomerTransfer> {
	/**
	 * 客户移交
	 */
	void transfer(CutomerTransfer cutomerTransfer);
	
}
