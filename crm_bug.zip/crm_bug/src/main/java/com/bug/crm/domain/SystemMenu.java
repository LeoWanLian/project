package com.bug.crm.domain;

import java.util.ArrayList;
import java.util.List;

/**
 * 系统菜单
 * 
 * @author MARIEROSE
 *
 */
public class SystemMenu extends BaseDomain {
	// `id` bigint(20) NOT NULL AUTO_INCREMENT,
	// `sn` varchar(255) NOT NULL,
	// `name` varchar(255) NOT NULL,
	// `icon` varchar(255) DEFAULT NULL,
	// `url` varchar(255) DEFAULT NULL,
	// `intro` varchar(255) DEFAULT NULL,
	// `parent_id` bigint(20) DEFAULT NULL,
	// 菜单编号
	private String sn;
	// 名称
	private String name;
	// 图标
	private String iconCls;
	// 地址
	private String url;
	// 简介
	private String intro;
	// 上级菜单
	private SystemMenu parent;

	private List<SystemMenu> children = new ArrayList<SystemMenu>();

	public String getText() {
		return this.name;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getIconCls() {
		return iconCls;
	}

	public void setIconCls(String iconCls) {
		this.iconCls = iconCls;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getIntro() {
		return intro;
	}

	public void setIntro(String intro) {
		this.intro = intro;
	}

	public SystemMenu getParent() {
		return parent;
	}

	public void setParent(SystemMenu parent) {
		this.parent = parent;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<SystemMenu> getChildren() {
		return children;
	}

	public void setChildren(List<SystemMenu> children) {
		this.children = children;
	}

	@Override
	public String toString() {
		return "SystemMenu [sn=" + sn + ", name=" + name + "]";
	}

}
