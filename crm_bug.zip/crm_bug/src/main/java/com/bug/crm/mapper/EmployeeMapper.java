package com.bug.crm.mapper;

import java.awt.Menu;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.bug.crm.domain.Employee;

/**
 * 部门管理的mapper
 *
 */
public interface EmployeeMapper extends BaseMapper<Employee> {

	@Select("select * from t_employee where username=#{username}")
	Employee findPWDbyUsername(String username);

	@Select("select DISTINCT p.resource from t_employee e join t_employee_role er on er.employee_id=e.id "
			+ "join t_role r on er.role_id=r.id join t_role_permission rp on rp.role_id=r.id "
			+ "join t_permission p on rp.permission_id=p.id where e.username=#{username}")
	List<String> findPermissionStringByUsername(String username);

	List<Menu> findMenusByUsername(String username);

	@Update("update t_employee set state=-1 where id =#{id}")
	void leave(Long id);

	// 删除t_employee_role中间表
	@Delete("delete from t_employee_role where employee_id=#{employeeId}")
	void deleteEmployeeRole(Long employeeId);

	void saveEmployeeRole(List<Map<String, Long>> roleMap);

	@Select("SELECT	DISTINCT r.name FROM t_employee e JOIN t_employee_role er ON er.employee_id = e.id JOIN t_role r "
			+ "ON r.id = er.role_id WHERE	e.username =#{username}")
	List<String> findRoleByUsername(String username);
}
