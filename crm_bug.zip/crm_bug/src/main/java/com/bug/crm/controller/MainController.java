package com.bug.crm.controller;

import java.awt.Menu;
import java.util.List;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bug.crm.mapper.EmployeeMapper;
import com.bug.crm.service.ICustomerService;
import com.bug.crm.service.IEmployeeService;

/**
 * 部门控制层
 * 
 * @author leowan
 */
@Controller
@RequestMapping("/main")
public class MainController {
	
	@Autowired
	ICustomerService customerService;
	
	@Autowired
	EmployeeMapper employeeMapper;

	// 一个方法显示页面,其他都返回json
	@RequestMapping("/list")
	public String list() {
		return "main";
	}

	// 显示动态菜单
	@RequestMapping("/left")
	@ResponseBody
	public List<Menu> left() {
		// 获取当前身份认证成功的对象
		Subject currentUser = SecurityUtils.getSubject();
		String username = (String) currentUser.getPrincipal();
		return employeeMapper.findMenusByUsername(username);
	}
	
	/**
	 * 报表数据
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/highChart")
	public Object highChart() {
		return customerService.highChart();
	}
	
}
