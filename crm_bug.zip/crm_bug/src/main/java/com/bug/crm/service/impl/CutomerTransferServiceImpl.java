package com.bug.crm.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bug.crm.domain.Customer;
import com.bug.crm.domain.CutomerTransfer;
import com.bug.crm.mapper.CustomerMapper;
import com.bug.crm.mapper.CustomerTransferMapper;
import com.bug.crm.service.ICutomerTransferService;

/**
 * 子类部门管理的service层实现,必须有@service注解
 * 
 * @author yufeifan
 * 潜在客户发展计划
 */
@Service
public class CutomerTransferServiceImpl extends BaseServiceImpl<CutomerTransfer> implements ICutomerTransferService {
	@Autowired
	private CustomerMapper customerMapper;
	@Autowired
	private CustomerTransferMapper customerTransferMapper;
	/**
	 * 客户移交
	 */
	@Transactional
	@Override
	public void transfer(CutomerTransfer cutomerTransfer) {
		
		
		//这里的到 的id实际上是 customer id
		Customer customer = customerMapper.get(cutomerTransfer.getId());
		//改变客户的营销人员
		customer.setSeller(cutomerTransfer.getNewSeller());
//		保存客户
		customerMapper.update(customer);
		
		
		
		//清空id
		cutomerTransfer.setId(null);
		//保存移交记录
		customerTransferMapper.save(cutomerTransfer);
		
	}

}
