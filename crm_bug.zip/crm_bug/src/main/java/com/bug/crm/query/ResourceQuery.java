package com.bug.crm.query;

public class ResourceQuery extends BaseQuery{

}
