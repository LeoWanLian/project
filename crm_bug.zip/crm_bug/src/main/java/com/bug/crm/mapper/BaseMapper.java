package com.bug.crm.mapper;

import java.util.List;

import com.bug.crm.domain.SystemDictionaryItem;
import com.bug.crm.query.BaseQuery;

/**
 * Mapper的基础接口
 *
 * @param <T>
 * @author leowan
 */
public interface BaseMapper<T> {
	void save(T t);

	void update(T t);

	void delete(Long id);

	T get(Long id);

	List<T> getAll();
	
	int findTotalByQuery(BaseQuery baseQuery);
	
	List<T> findLimitByQuery(BaseQuery baseQuery);
	/**
	 * 根据数据字典父类型名称  获取数据字典明细
	 */
	List<SystemDictionaryItem> findSystemDictionaryItemByParent(String typeName);
	//批量删除
	void deleteAll(Long[] ids);
	
}
