package com.bug.crm.service;

import java.util.List;

import com.bug.crm.domain.ContractItem;

/**
 * 
 * @author leowan
 * 日期:2018年3月29日
 * 类描述:合同明细service层接口
 */
public interface IContractItemService extends IBaseService<ContractItem> {

	
}
