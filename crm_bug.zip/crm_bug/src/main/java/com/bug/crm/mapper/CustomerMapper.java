package com.bug.crm.mapper;

import java.util.List;
import java.util.Map;

import com.bug.crm.domain.Customer;

/**
 * 
 * 
 * @author 客户信息管理
 */
public interface CustomerMapper extends BaseMapper<Customer> {
	/**
	 * 将客户放入资源池
	 */
	void putInPool(Long[] str2);

	/**
	 * 将资源池客户转为客户
	 */
	void removePool(Long[] str2);

	/**
	 * 制作报表的数据
	 * 
	 * @return
	 */
	List<Map<String, Long>> highChart();

}
