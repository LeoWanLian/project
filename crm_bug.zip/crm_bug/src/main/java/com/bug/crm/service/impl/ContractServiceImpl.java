package com.bug.crm.service.impl;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bug.crm.domain.Contract;
import com.bug.crm.domain.ContractItem;
import com.bug.crm.mapper.ContractItemMapper;
import com.bug.crm.mapper.ContractMapper;
import com.bug.crm.query.ContractItemQuery;
import com.bug.crm.query.PageList;
import com.bug.crm.service.IContractItemService;
import com.bug.crm.service.IContractService;

/**
 * 子类部门管理的service层实现,必须有@service注解
 * 
 * @author leowan
 */
@Service
public class ContractServiceImpl extends BaseServiceImpl<Contract> implements IContractService {
	@Autowired
	IContractItemService contractItemService;

	@Transactional
	@Override
	public void delete(Long[] itemsIds) {

		for (Long long1 : itemsIds) {
			// 将前台传过来的合同ID封装到查询对象里面
			ContractItemQuery baseQuery = new ContractItemQuery();
			baseQuery.setContractId(long1);
			// 通过前台传过来的合同ID,查到对应的合同明细.
			PageList findByQuery = contractItemService.findByQuery(baseQuery);
			// 获取到合同对应所有的明细list
			List<ContractItem> list = findByQuery.getRows();
			Long[] ids = new Long[list.size()];
			if (list.size() != 0) {
				// 遍历合同明细,删除所有
				for (int i = 0; i < list.size(); i++) {
					ids[i] = list.get(i).getId();
				}
				contractItemService.deleteAll(ids);
			}
			delete(long1);
		}
	}
}
