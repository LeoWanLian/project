package com.bug.crm.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import com.bug.crm.domain.Role;

/**
 * 部门管理的mapper
 *
 */
public interface RoleMapper extends BaseMapper<Role> {
	// 删除t_role_permission中间表
	@Delete("delete from t_role_permission where role_id=#{roleId}")
	void deleteRolePermission(Long roleId);
	
	void saveRolePermission(List<Map<String, Long>> permissionMap);
}
