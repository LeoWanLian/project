package com.bug.crm.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bug.crm.domain.WarrantyBill;
import com.bug.crm.domain.WarrantyBillItem;
import com.bug.crm.query.PageList;
import com.bug.crm.query.WarrantyBillItemQuery;
import com.bug.crm.query.WarrantyBillQuery;
import com.bug.crm.service.IContractService;
import com.bug.crm.service.ICustomerService;
import com.bug.crm.service.IWarrantyBillItemService;
import com.bug.crm.service.IWarrantyBillService;
import com.bug.crm.util.AjaxResult;

/**
 * 定金订单控制层
 * 
 * @author leowan
 */
@Controller
@RequestMapping("/warrantyBill")
public class WarrantyBillController {
	@Autowired
	IWarrantyBillService warrantyBillService;
	@Autowired
	ICustomerService customerService;
	@Autowired
	IWarrantyBillItemService warrantyBillItemService;
	
	@Autowired
	IContractService contractService;

	// 一个方法显示页面,其他都返回json
	@RequestMapping("/list")
	public String list() {
		return "warrantyBill";
	}

	@RequestMapping("/json")
	@ResponseBody
	public PageList json(WarrantyBillQuery baseQuery) {
		return warrantyBillService.findByQuery(baseQuery);
	}

	// 保存方法
	@RequestMapping("/save")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult save(WarrantyBill bill) {
		if(bill.getFlag()!=null){
			bill.setId(null);
		}
		// 将前台传过来的合同ID封装到查询对象里面
		WarrantyBillItemQuery baseQuery = new WarrantyBillItemQuery();
		baseQuery.setBillId(bill.getId());
		// 通过前台传过来的合同ID,查到对应的合同明细.
		PageList findByQuery = warrantyBillItemService.findByQuery(baseQuery);
		// 数据库已存在的明细
		List<WarrantyBillItem> items3 = findByQuery.getRows();
		// 前台传过来的明细
		List<WarrantyBillItem> items = bill.getItems();
		if (items == null) {
			items = new ArrayList<WarrantyBillItem>();
		}
		try {
			if (bill.getId() != null) {//修改
				if("".equals(bill.getSn())||bill.getSn()==null){
					bill.setSn("sn-"+new SimpleDateFormat("yyyyMMddHHmmSSS").format(new Date()));
				}
				warrantyBillService.update(bill);
				// 遍历删除合同已有的明细
				for (WarrantyBillItem warrantyBillItem : items3) {
					warrantyBillItemService.delete(warrantyBillItem.getId());
				}
				// 再把前台传过来的明细保存到数据库
				for (WarrantyBillItem warrantyBillItem : items) {
					warrantyBillItem.setBill(bill);
					warrantyBillItemService.save(warrantyBillItem);
				}
			} else {//新增
				// 先保存一方合同
				bill.setSn("sn-"+new SimpleDateFormat("yyyyMMddHHmmSSS").format(new Date()));
				warrantyBillService.save(bill);
				// 再保存多方,明细
				for (WarrantyBillItem warrantyBillItem : items) {
					warrantyBillItem.setBill(bill);
					warrantyBillItemService.save(warrantyBillItem);
				}
			}
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("保存异常:" + e.getMessage());
		}
	}

	@RequestMapping("/delete")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult delete(String ids) {
		try {
			// 截取字符串
			String[] strArr = ids.split(",");
			// 将前台传过来的字符串转成long数组
			Long[] str2 = new Long[strArr.length];
			for (int i = 0; i < strArr.length; i++) {
				str2[i] = Long.valueOf(strArr[i]);
			}
			warrantyBillService.delete(str2);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}

	@RequestMapping("/getCustomerData")
	@ResponseBody
	// 下拉选择客户信息
	public Object getCustomerData() {
		return customerService.getAll();
	}

	@RequestMapping("/findItemsById")
	@ResponseBody
	// 根据合同Id查询对应的明细
	public PageList findItemsById(WarrantyBillItemQuery baseQuery) {
		// contractItemService.findByQuery(baseQuery));
		return warrantyBillItemService.findByQuery(baseQuery);
	}

}
