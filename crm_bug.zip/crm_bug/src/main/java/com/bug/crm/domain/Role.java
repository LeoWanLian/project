package com.bug.crm.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 系统角色管理
 * 
 * @author MARIEROSE
 *
 */
public class Role extends BaseDomain {
	// `id` bigint(20) NOT NULL AUTO_INCREMENT,
	// `sn` varchar(255) NOT NULL,
	// `name` varchar(255) NOT NULL,
	// `permission_id` bigint(20) DEFAULT NULL,

	// 名称
	private String name;
	// 角色编号
	private String sn;
	// 角色和权限多对多关系
	private List<Permission> permissions = new ArrayList<Permission>();

	// 专门处理中间表
	public List<Map<String, Long>> getPermissionMap() {
		List<Map<String, Long>> list = new ArrayList<Map<String, Long>>();
		for (Permission permission : getPermissions()) {
			Map<String, Long> map = new HashMap<String, Long>();// 就是一个domain对象
			map.put("roleId", getId());
			map.put("permissionId", permission.getId());
			list.add(map);
		}
		return list;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public List<Permission> getPermissions() {
		return permissions;
	}

	public void setPermissions(List<Permission> permissions) {
		this.permissions = permissions;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Role [name=" + name + ", sn=" + sn + "]";
	}

}
