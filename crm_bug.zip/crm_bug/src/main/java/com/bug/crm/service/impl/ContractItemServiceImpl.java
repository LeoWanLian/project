package com.bug.crm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bug.crm.domain.ContractItem;
import com.bug.crm.mapper.ContractItemMapper;
import com.bug.crm.query.ContractItemQuery;
import com.bug.crm.query.PageList;
import com.bug.crm.service.IContractItemService;

/**
 * 合同明细的service层实现,必须有@service注解
 * 
 * @author leowan
 */
@Service
public class ContractItemServiceImpl extends BaseServiceImpl<ContractItem> implements IContractItemService {

	
}
