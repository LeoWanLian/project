package com.bug.crm.query;

public class WarrantyBillItemQuery extends BaseQuery {
	private Long billId;

	public Long getBillId() {
		return billId;
	}

	public void setBillId(Long billId) {
		this.billId = billId;
	}

}
