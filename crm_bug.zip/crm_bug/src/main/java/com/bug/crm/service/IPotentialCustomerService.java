package com.bug.crm.service;

import com.bug.crm.domain.Customer;
import com.bug.crm.domain.PotentialCustomer;

/**
 * 
 * @author leowan
 * 日期:2018年3月29日
 * 类描述:定金订单service层接口
 */
public interface IPotentialCustomerService extends IBaseService<PotentialCustomer> {
	/**
	 * 潜在客户升级
	 */
	void upgrade(Customer customer);
	
}
 