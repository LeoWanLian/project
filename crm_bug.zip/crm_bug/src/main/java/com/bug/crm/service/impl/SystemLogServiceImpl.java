package com.bug.crm.service.impl;

import org.springframework.stereotype.Service;

import com.bug.crm.domain.SystemLog;
import com.bug.crm.service.ISystemLogService;

/**
 * 子类部门管理的service层实现,必须有@service注解
 *
 */
@Service
public class SystemLogServiceImpl extends BaseServiceImpl<SystemLog> implements ISystemLogService {
}
