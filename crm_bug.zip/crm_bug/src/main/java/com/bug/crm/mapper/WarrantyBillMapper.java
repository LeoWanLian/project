package com.bug.crm.mapper;

import com.bug.crm.domain.WarrantyBill;

/**
 * 保修订单的mapper
 * 
 * @author leowan
 */
public interface WarrantyBillMapper extends BaseMapper< WarrantyBill> {

}
