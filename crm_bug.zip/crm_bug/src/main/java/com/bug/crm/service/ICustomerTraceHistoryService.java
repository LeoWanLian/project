package com.bug.crm.service;

import com.bug.crm.domain.CustomerTraceHistory;

/**
 * 客户跟进历史
 * 
 * @author leowan
 */
public interface ICustomerTraceHistoryService extends IBaseService<CustomerTraceHistory> {

}
