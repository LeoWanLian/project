package com.bug.crm.query;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class PotentialCustomerQuery extends BaseQuery {
	//潜在客户姓名
	private String name;
	//客户来源
	private Integer customerSourceId;
	//录入员
	private  Integer inputUserId;
	//成功几率
	private Integer successRate;
	//联系人
	private String linkMan;
	//联系电话
	private String linkManTel;
	// 起始时间
	private Date beginTime;
	// 结束时间
	private Date endTime;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date getBeginTime() {
		return beginTime;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date getEndTime() {
		return endTime;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setCustomerSourceId(Integer customerSourceId) {
		this.customerSourceId = customerSourceId;
	}

	public void setInputUserId(Integer inputUserId) {
		this.inputUserId = inputUserId;
	}

	public void setSuccessRate(Integer successRate) {
		this.successRate = successRate;
	}

	public void setLinkMan(String linkMan) {
		this.linkMan = linkMan;
	}

	public void setLinkManTel(String linkManTel) {
		this.linkManTel = linkManTel;
	}
	
	

}
