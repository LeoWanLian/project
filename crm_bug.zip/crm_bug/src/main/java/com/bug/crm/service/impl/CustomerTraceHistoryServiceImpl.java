package com.bug.crm.service.impl;

import org.springframework.stereotype.Service;

import com.bug.crm.domain.CustomerTraceHistory;
import com.bug.crm.service.ICustomerTraceHistoryService;

/**
 * 客户跟进历史
 * 
 * @author leowan
 */
@Service
public class CustomerTraceHistoryServiceImpl extends BaseServiceImpl<CustomerTraceHistory> implements ICustomerTraceHistoryService {

}
