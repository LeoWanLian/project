package com.bug.crm.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class SystemLog extends BaseDomain {
	// `id` bigint(20) NOT NULL AUTO_INCREMENT,
	// `opUser` varchar(255) NOT NULL,
	// `opTime` datetime NOT NULL,
	// `opIp` varchar(255) DEFAULT NULL,
	// `function` varchar(255) DEFAULT NULL,
	// `params` varchar(255) DEFAULT NULL,
	// 操作用户
	private String opUser;
	// 操作时间
	private Date opTime;
	// 登录IP
	private String opIp;
	// 使用功能（方法）
	private String function;
	// 操作参数信息
	private String params;

	public String getOpUser() {
		return opUser;
	}

	public void setOpUser(String opUser) {
		this.opUser = opUser;
	}

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date getOpTime() {
		return opTime;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public void setOpTime(Date opTime) {
		this.opTime = opTime;
	}

	public String getOpIp() {
		return opIp;
	}

	public void setOpIp(String opIp) {
		this.opIp = opIp;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public String getParams() {
		return params;
	}

	public void setParams(String params) {
		this.params = params;
	}

	@Override
	public String toString() {
		return "SystemLog [opUser=" + opUser + ", opTime=" + opTime + "]";
	}

}
