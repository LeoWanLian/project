package com.bug.crm.mapper;

import com.bug.crm.domain.Resource;

/**
 *	部门管理的mapper 
 *
 */
public interface ResourceMapper extends BaseMapper<Resource>{
	
}
