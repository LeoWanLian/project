package com.bug.crm.domain;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 合同明细 组合关系 (多方)
 * 
 * @author leowan
 */
public class ContractItem extends BaseDomain {
	// 付款时间
	private Date payTime;
	// 付款金额
	private BigDecimal money;
	// 所占比例
	private String scale;
	// 是否付款 0未付款,1已付款，-1异常
	private Integer isPayment = 0;
	// 对应合同(一方)
	private Contract contract;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date getPayTime() {
		return payTime;
	}
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public void setPayTime(Date payTime) {
		this.payTime = payTime;
	}

	public BigDecimal getMoney() {
		return money;
	}

	public void setMoney(BigDecimal money) {
		this.money = money;
	}

	public String getScale() {
		return scale;
	}

	public void setScale(String scale) {
		this.scale = scale;
	}

	public Integer getIsPayment() {
		return isPayment;
	}

	public void setIsPayment(Integer isPayment) {
		this.isPayment = isPayment;
	}

	public Contract getContract() {
		return contract;
	}

	public void setContract(Contract contract) {
		this.contract = contract;
	}
	@Override
	public String toString() {
		return "ContractItem [payTime=" + payTime + ", money=" + money + ", scale=" + scale + ", isPayment=" + isPayment
				+ ", contract=" + contract + "]";
	}



}
