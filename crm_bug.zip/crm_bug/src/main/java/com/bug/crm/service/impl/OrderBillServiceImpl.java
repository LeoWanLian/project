package com.bug.crm.service.impl;

import org.springframework.stereotype.Service;

import com.bug.crm.domain.OrderBill;
import com.bug.crm.service.IOrderBillService;

/**
 * 子类部门管理的service层实现,必须有@service注解
 * 
 * @author leowan
 */
@Service
public class OrderBillServiceImpl extends BaseServiceImpl<OrderBill> implements IOrderBillService {
}
