package com.bug.crm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bug.crm.domain.Department;
import com.bug.crm.mapper.DepartmentMapper;
import com.bug.crm.query.DepartmentQuery;
import com.bug.crm.query.PageList;
import com.bug.crm.service.IDepartmentService;

/**
 * 子类部门管理的service层实现,必须有@service注解
 * 
 * @author leowan
 */
@Service
public class DepartmentServiceImpl extends BaseServiceImpl<Department> implements IDepartmentService {

	@Autowired
	DepartmentMapper departmentMapper;

	@Override
	public List<Department> getTreeData() {
		return departmentMapper.getTreeData();
	}

	

}
