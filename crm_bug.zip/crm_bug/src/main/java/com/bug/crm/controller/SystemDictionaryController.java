package com.bug.crm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bug.crm.domain.SystemDictionary;
import com.bug.crm.query.SystemDictionaryQuery;
import com.bug.crm.query.PageList;
import com.bug.crm.service.ISystemDictionaryService;
import com.bug.crm.util.AjaxResult;

/**
 * 部门控制层
 * 
 * @author leowan
 */
@Controller
@RequestMapping("/systemDictionary")
public class SystemDictionaryController {
	@Autowired
	ISystemDictionaryService systemDictionaryService;

	// 一个方法显示页面,其他都返回json
	@RequestMapping("/list")
	public String list() {
		return "systemDictionary";
	}

	@RequestMapping("/json")
	@ResponseBody
	public PageList json(SystemDictionaryQuery baseQuery) {
		return systemDictionaryService.findByQuery(baseQuery);
	}

	// 保存方法
	@RequestMapping("/save")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult save(SystemDictionary systemDictionary) {
		try {
			if (systemDictionary.getId() != null) {
				systemDictionaryService.update(systemDictionary);
			} else {
				systemDictionaryService.save(systemDictionary);
			}
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("保存异常:" + e.getMessage());
		}
	}

	@RequestMapping("/delete")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult delete(Long id) {
		try {
			systemDictionaryService.delete(id);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}

}
