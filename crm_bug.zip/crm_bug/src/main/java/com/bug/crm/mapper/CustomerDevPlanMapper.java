package com.bug.crm.mapper;

import com.bug.crm.domain.CustomerDevPlan;
/**
 * 
 * @author Administrator
 * 日期:2018年3月29日
 * 类描述:（潜在）客户开发计划
 */
public interface CustomerDevPlanMapper extends BaseMapper<CustomerDevPlan>{
	
}
