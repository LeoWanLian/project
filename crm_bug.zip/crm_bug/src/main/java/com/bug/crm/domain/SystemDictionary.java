package com.bug.crm.domain;

import java.io.Serializable;

/**
 * 数据字典
 * 
 * @author MARIEROSE
 *
 */
public class SystemDictionary extends BaseDomain implements Serializable{
	// `id` bigint(20) NOT NULL AUTO_INCREMENT,
	// `sn` varchar(255) NOT NULL,
	// `name` varchar(255) NOT NULL,
	// `intro` varchar(255) DEFAULT NULL,
	// `state` int(20) DEFAULT NULL,、
	// 字段目录编号
	private String sn;
	// 名称
	private String name;
	// 字段目录简介
	private String intro;
	// 状态
	private Integer state = 0;

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getIntro() {
		return intro;
	}

	public void setIntro(String intro) {
		this.intro = intro;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "SystemDictionary [sn=" + sn + ", name=" + name + ", intro=" + intro + "]";
	}

}
