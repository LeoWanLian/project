package com.bug.crm.domain;

import java.util.List;

/**
 * 部门管理
 *
 */
public class Department extends BaseDomain {

	// id` bigint(20) NOT NULL AUTO_INCREMENT,
	// `sn` varchar(255) NOT NULL,
	// `name` varchar(255) NOT NULL,
	// `children_id` bigint(20) DEFAULT NULL,
	// `dirPath` varchar(255) DEFAULT NULL,
	// `state` int(20) DEFAULT NULL,
	// `manager_id` bigint(20) DEFAULT NULL,
	// `parent_id` bigint(20) DEFAULT NULL,

	// 名称
	private String name;
	// 部门编号
	private String sn;
	// 路径
	private String dirPath;
	// 状态
	private Integer state;
	// 部门经理
	private Employee manager;
	// 上级部门
	private Department parent;
	// 子部门
	private List<Department> children;
	// easyui兼容代码
	public String getText() {
		return name;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getDirPath() {
		return dirPath;
	}

	public void setDirPath(String dirPath) {
		this.dirPath = dirPath;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Employee getManager() {
		return manager;
	}

	public void setManager(Employee manager) {
		this.manager = manager;
	}

	public Department getParent() {
		return parent;
	}

	public void setParent(Department parent) {
		this.parent = parent;
	}

	
	public List<Department> getChildren() {
		return children;
	}

	public void setChildren(List<Department> children) {
		this.children = children;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Department [name=" + name + ", sn=" + sn + "]";
	}

}
