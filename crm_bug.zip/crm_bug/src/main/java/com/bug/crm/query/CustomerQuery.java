package com.bug.crm.query;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.bug.crm.controller.UserContext;
import com.fasterxml.jackson.annotation.JsonFormat;

public class CustomerQuery extends BaseQuery {
	// 性别
	private Boolean gender;
	// 职业
	private Integer jobId;
	// 收入水平
	private Integer salaryLevelId;
	// 客户来源
	private Integer customerSourceId;
	// 营销人员
	private Integer sellerId;
	// 录入员
	private Integer inputUserId;
	// 起始时间
	private Date beginTime;
	// 结束时间
	private Date endTime;
	//是否查询资源池的标记字段,如果不为空,表示查询资源池
	private Integer sign;
	
	//是否为管理员角色
	private Boolean isAdmin;
	
	//当前登录用户id
	private Long userId;
	
	
	
	public Boolean getIsAdmin() {
		return UserContext.isAdmin();
	}

	public void setIsAdmin(Boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public Long getUserId() {
		return UserContext.getLoginUser().getId();
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date getBeginTime() {
		return beginTime;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date getEndTime() {
		return endTime;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Boolean getGender() {
		return gender;
	}

	public void setGender(Boolean gender) {
		this.gender = gender;
	}

	public Integer getJobId() {
		return jobId;
	}

	public void setJobId(Integer jobId) {
		this.jobId = jobId;
	}

	public Integer getSalaryLevelId() {
		return salaryLevelId;
	}

	public void setSalaryLevelId(Integer salaryLevelId) {
		this.salaryLevelId = salaryLevelId;
	}

	public Integer getCustomerSourceId() {
		return customerSourceId;
	}

	public void setCustomerSourceId(Integer customerSourceId) {
		this.customerSourceId = customerSourceId;
	}

	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

	public Integer getInputUserId() {
		return inputUserId;
	}

	public void setInputUserId(Integer inputUserId) {
		this.inputUserId = inputUserId;
	}

	public Integer getSign() {
		return sign;
	}

	public void setSign(Integer sign) {
		this.sign = sign;
	}
	
	
}
