package com.bug.crm.domain;

import java.io.Serializable;
import java.util.List;

/**
 * 数据字典明细
 * 
 * @author MARIEROSE
 *
 */
public class SystemDictionaryItem extends BaseDomain implements Serializable{
	// `id` bigint(20) NOT NULL AUTO_INCREMENT,
	// `name` varchar(255) NOT NULL,
	// `requence` bigint(20) DEFAULT NULL,
	// `intro` varchar(255) DEFAULT NULL,
	// `details_id` bigint(20) DEFAULT NULL,
	// `parent_id` bigint(20) NOT NULL,

	// 名称
	private String name;
	// 字典明细序号
	private Integer requence;
	// 字典明细简介
	private String intro;
	// 字典目录
	private SystemDictionary parent;
	private List<SystemDictionaryItem> details;

	public Integer getRequence() {
		return requence;
	}

	public void setRequence(Integer requence) {
		this.requence = requence;
	}

	public String getIntro() {
		return intro;
	}

	public void setIntro(String intro) {
		this.intro = intro;
	}

	public SystemDictionary getParent() {
		return parent;
	}

	public void setParent(SystemDictionary parent) {
		this.parent = parent;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<SystemDictionaryItem> getDetails() {
		return details;
	}

	public void setDetails(List<SystemDictionaryItem> details) {
		this.details = details;
	}

	@Override
	public String toString() {
		return "SystemDictionaryItem [name=" + name + ", requence=" + requence + ", intro=" + intro + "]";
	}

}
