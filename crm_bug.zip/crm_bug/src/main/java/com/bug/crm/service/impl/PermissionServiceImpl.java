package com.bug.crm.service.impl;

import org.springframework.stereotype.Service;

import com.bug.crm.domain.Permission;
import com.bug.crm.service.IPermissionService;

/**
 * 子类部门管理的service层实现,必须有@service注解
 *
 */
@Service
public class PermissionServiceImpl extends BaseServiceImpl<Permission> implements IPermissionService {
}
