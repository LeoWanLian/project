package com.bug.crm.service.impl;

import org.springframework.stereotype.Service;

import com.bug.crm.domain.WarrantyBillItem;
import com.bug.crm.service.IWarrantyBillItemService;

/**
 * 合同明细的service层实现,必须有@service注解
 * 
 * @author leowan
 */
@Service
public class WarrantyBillItemServiceImpl extends BaseServiceImpl<WarrantyBillItem> implements IWarrantyBillItemService {

}
