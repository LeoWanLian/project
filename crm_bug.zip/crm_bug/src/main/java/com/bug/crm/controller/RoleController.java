package com.bug.crm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bug.crm.domain.Role;
import com.bug.crm.query.RoleQuery;
import com.bug.crm.query.PageList;
import com.bug.crm.service.IRoleService;
import com.bug.crm.util.AjaxResult;

/**
 * 部门控制层
 * 
 * @author leowan
 */
@Controller
@RequestMapping("/role")
public class RoleController {
	@Autowired
	IRoleService roleService;

	// 一个方法显示页面,其他都返回json
	@RequestMapping("/list")
	public String list() {
		return "role";
	}

	@RequestMapping("/json")
	@ResponseBody
	public PageList json(RoleQuery baseQuery) {
		return roleService.findByQuery(baseQuery);
	}

	// 保存方法
	@RequestMapping("/save")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult save(Role role) {
		try {
			if (role.getId() != null) {
				roleService.update(role);
			} else {
				roleService.save(role);
			}
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("保存异常:" + e.getMessage());
		}
	}

	@RequestMapping("/delete")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult delete(Long id) {
		try {
			roleService.delete(id);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}

}
