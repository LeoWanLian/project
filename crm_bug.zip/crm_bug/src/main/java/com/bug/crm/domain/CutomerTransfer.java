package com.bug.crm.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 
 * @author Administrator 日期:2018年3月29日 类描述:客户移交记录
 */
public class CutomerTransfer extends BaseDomain {
	private Customer customer;// 客户
	private Employee transUser;// 移交人员(实行移交操作的管理人员)
	private Date transTime;// 移交时间
	private Employee oldSeller;// 老市场专员(客户上的原始市场人员)
	private Employee newSeller;// 新市场专员(由公司重新纸指派后的新市场人员)
	private String transReason;// 移交原因

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Employee getTransUser() {
		return transUser;
	}

	public void setTransUser(Employee transUser) {
		this.transUser = transUser;
	}

	@JsonFormat(pattern = "yyyy-MM-dd ", timezone = "GMT+8")
	public Date getTransTime() {
		return transTime;
	}
	@DateTimeFormat(pattern = "yyyy-MM-dd ")
	public void setTransTime(Date transTime) {
		this.transTime = transTime;
	}

	public Employee getOldSeller() {
		return oldSeller;
	}

	public void setOldSeller(Employee oldSeller) {
		this.oldSeller = oldSeller;
	}

	public Employee getNewSeller() {
		return newSeller;
	}

	public void setNewSeller(Employee newSeller) {
		this.newSeller = newSeller;
	}

	public String getTransReason() {
		return transReason;
	}

	public void setTransReason(String transReason) {
		this.transReason = transReason;
	}

	@Override
	public String toString() {
		return "CutomerTransfer [customer=" + customer + ", transTime=" + transTime + ", transReason=" + transReason
				+ ", getId()=" + getId() + "]";
	}

}
