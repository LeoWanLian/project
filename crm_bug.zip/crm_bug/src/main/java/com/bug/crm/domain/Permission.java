package com.bug.crm.domain;

import java.io.Serializable;

/**
 * 系统权限管理
 * 
 * @author MARIEROSE
 *
 */
public class Permission extends BaseDomain implements Serializable{
	// `id` bigint(20) NOT NULL AUTO_INCREMENT,
	// `name` varchar(255) NOT NULL,
	// `resource` varchar(255) NOT NULL,
	// `menu_id` bigint(20) NOT NULL,

	// 名称
	private String name;
	// 访问路径
	private String url;
	// 权限字符串
	private String resource;
	
	
	private Integer menuId;

	// 额外增加的字段
	private Integer state = 0;// 状态:0:正常(默认),-1:禁用

	public String getResource() {
		return resource;
	}

	public void setResource(String resource) {
		this.resource = resource;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getMenuId() {
		return menuId;
	}

	public void setMenuId(Integer menuId) {
		this.menuId = menuId;
	}

	@Override
	public String toString() {
		return "Permission [name=" + name + ", resource=" + resource + "]";
	}

}
