package com.bug.crm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bug.crm.domain.Department;
import com.bug.crm.query.DepartmentQuery;
import com.bug.crm.query.PageList;
import com.bug.crm.service.IDepartmentService;
import com.bug.crm.service.IEmployeeService;
import com.bug.crm.util.AjaxResult;

/**
 * 部门控制层
 * 
 * @author leowan
 */
@Controller
@RequestMapping("/department")
public class DepartmentController {
	@Autowired
	IDepartmentService departmentService;
	@Autowired
	IEmployeeService employeeService;

	// 一个方法显示页面,其他都返回json
	@RequestMapping("/list")
	public String list() {
		return "department";
	}

	@RequestMapping("/json")
	@ResponseBody
	public PageList json(DepartmentQuery baseQuery) {
		return departmentService.findByQuery(baseQuery);
	}

	// 保存方法
	@RequestMapping("/save")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult save(Department department) {
		try {
			if (department.getId() != null) {
				departmentService.update(department);
			} else {
				departmentService.save(department);
			}
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("保存异常:" + e.getMessage());
		}
	}

	@RequestMapping("/delete")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult delete(String ids) {
		try {
			//截取字符串
			String[] strArr = ids.split(",");
			//将前台传过来的字符串转成long数组
	        Long[] str2 = new Long[strArr.length];
	        for (int i = 0; i < strArr.length; i++) {
	            str2[i] = Long.valueOf(strArr[i]);
	        }
			departmentService.deleteAll(str2);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}

	@RequestMapping("/getTreeData")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	// 下拉树选择上级部门
	public Object getTreeData() {
		return departmentService.getTreeData();
	}
	
	@RequestMapping("/getManagerData")
	@ResponseBody
	// 下拉选择部门经理
	public Object getManagerData() {
		return employeeService.getAll();
	}

}
