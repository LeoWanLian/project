package com.bug.crm.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bug.crm.domain.Employee;
import com.bug.crm.mapper.EmployeeMapper;
import com.bug.crm.service.IEmployeeService;

/**
 * 子类部门管理的service层实现,必须有@service注解
 *
 */
@Service
public class EmployeeServiceImpl extends BaseServiceImpl<Employee> implements IEmployeeService {

	@Autowired
	EmployeeMapper employeeMapper;

	@Override
	public void leave(Long id) {
		employeeMapper.leave(id);
	}

	// 自己实现级联删除、级联保存、级联修改的效果
	@Override
	@Transactional
	public void delete(Long id) {
		// 先删除中间表
		employeeMapper.deleteEmployeeRole(id);
		// 在删除角色表
		employeeMapper.delete(id);
	}

	@Override
	@Transactional
	public void save(Employee employee) {
		employeeMapper.save(employee);
		if (employee.getRoles().size() > 0) {
			employeeMapper.saveEmployeeRole(employee.getRoleMap());
		}
	}

	@Override
	@Transactional
	public void update(Employee employee) {
		employeeMapper.deleteEmployeeRole(employee.getId());
		employeeMapper.update(employee);
		if (employee.getRoles().size() > 0) {
			employeeMapper.saveEmployeeRole(employee.getRoleMap());
		}
	}
}
