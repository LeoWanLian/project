package com.bug.crm.controller;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bug.crm.domain.CutomerTransfer;
import com.bug.crm.domain.Employee;
import com.bug.crm.query.CutomerTransferQuery;
import com.bug.crm.service.ICustomerService;
import com.bug.crm.service.ICutomerTransferService;
import com.bug.crm.service.IEmployeeService;
import com.bug.crm.util.AjaxResult;

/**
 * 客户移交记录
 * 
 * @author yff
 */
@Controller
@RequestMapping("/cutomerTransfer")
public class CutomerTransferController {
	@Autowired
	ICutomerTransferService cutomerTransferService;

	@Autowired
	IEmployeeService employeeService;
	@Autowired
	ICustomerService customerService;

	// 一个方法显示页面,其他都返回json
	@RequestMapping("/list")
	public String list(Model model) {
		return "cutomerTransfer";
	}

	/**
	 * 返回列表数据
	 */
	@RequestMapping("/json")
	@ResponseBody
	public Object json(CutomerTransferQuery cutomerTransferQuery) {
		return cutomerTransferService.findByQuery(cutomerTransferQuery);
	}

	// 保存方法
	@RequestMapping("/save")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult save(CutomerTransfer cutomerTransfer, HttpServletRequest request) {
		try {
			if (cutomerTransfer.getId() != null) {
				
				cutomerTransferService.update(cutomerTransfer);
			} else {
				Employee transUser = UserContext.getLoginUser();
				cutomerTransfer.setTransUser(transUser);
				
				cutomerTransferService.save(cutomerTransfer);
			}
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("保存异常:" + e.getMessage());
		}
	}
	// 保存方法
	@RequestMapping("/transfer")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult transfer(CutomerTransfer cutomerTransfer, HttpServletRequest request) {
		try {
				cutomerTransfer.setTransTime(new Date());
				Employee employee = UserContext.getLoginUser();
				if(employee!=null){
					cutomerTransfer.setTransUser(employee);//添加录入员
				}
				cutomerTransferService.transfer(cutomerTransfer);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("保存异常:" + e.getMessage());
		}
	}

	@RequestMapping("/delete")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult delete(String ids) {
		try {
			//截取字符串
			String[] strArr = ids.split(",");
			//将前台传过来的字符串转成long数组
	        Long[] str2 = new Long[strArr.length];
	        for (int i = 0; i < strArr.length; i++) {
	            str2[i] = Long.valueOf(strArr[i]);
	        }
	        cutomerTransferService.deleteAll(str2);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}

	/**
	 * 获取所有客户
	 */
	@RequestMapping("/customer")
	@ResponseBody
	public Object getAllCustomer() {
		return customerService.getAll();

	}

	/**
	 * 获取所有跟进方式
	 */
	@RequestMapping("/traceType")
	@ResponseBody
	public Object getAllTraceType() {
		return cutomerTransferService.findSystemDictionaryItemByParent("跟进方式");

	}

	/**
	 * 
	 */
	@RequestMapping("/trdfsdfeUser")
	@ResponseBody
	public Object getAllcutomerTransferSource() {
		return cutomerTransferService.findSystemDictionaryItemByParent("客户来源");

	}

	/**
	 * 获取所员工(跟进人)
	 */
	@RequestMapping("/traceUser")
	@ResponseBody
	public Object getAlltraceUser() {
		return employeeService.getAll();

	}

}
