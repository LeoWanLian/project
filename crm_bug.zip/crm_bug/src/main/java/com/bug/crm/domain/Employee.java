package com.bug.crm.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 员工管理
 *
 */
public class Employee extends BaseDomain {

	// `id` bigint(20) NOT NULL AUTO_INCREMENT,
	// `username` varchar(255) NOT NULL,
	// `password` varchar(255) NOT NULL,
	// `realName` varchar(255) NOT NULL,
	// `tel` varchar(255) NOT NULL,
	// `email` varchar(255) DEFAULT NULL,
	// `inputTime` datetime DEFAULT NULL,
	// `state` int(11) DEFAULT NULL,
	// `department_id` bigint(20) DEFAULT NULL,
	// `role_id` bigint(20) DEFAULT NULL,

	// 名称
	private String username;
	// 真实姓名
	private String realName;
	// 密码
	private String password;
	// 电话
	private String tel;
	// 邮箱
	private String email;
	// 盐
	private String salt="bug";
	// 录入时间
	private Date inputTime = new Date();
	// 状态
	private Integer state = 0;
	private Integer roleid;
	// 部门
	private Department department;
	// 员工和角色多对多
	private List<Role> roles = new ArrayList<Role>();

	// 专门处理中间表
	public List<Map<String, Long>> getRoleMap() {
		List<Map<String, Long>> list = new ArrayList<Map<String, Long>>();
		for (Role role : getRoles()) {
			Map<String, Long> map = new HashMap<String, Long>();// 就是一个domain对象
			map.put("employeeId", getId());
			map.put("roleId", role.getId());
			list.add(map);
		}
		return list;
	}
	
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	public Date getInputTime() {
		return inputTime;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	public void setInputTime(Date inputTime) {
		this.inputTime = inputTime;
	}

	public String getSalt() {
		return salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getRoleid() {
		return roleid;
	}

	public void setRoleid(Integer roleid) {
		this.roleid = roleid;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public List<Role> getRoles() {
		return roles;
	}

	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public String toString() {
		return "Employee [username=" + username + ", realName=" + realName + ", password=" + password + ", tel=" + tel
				+ "]";
	}

}
