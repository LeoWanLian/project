package com.bug.crm.shiro;

import java.util.List;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.util.ByteSource;
import org.springframework.beans.factory.annotation.Autowired;

import com.bug.crm.domain.Employee;
import com.bug.crm.mapper.EmployeeMapper;

public class CRMJdbcRealm extends AuthorizingRealm {

	EmployeeMapper employeeMapper;

	@Autowired
	public void setEmployeeMapper(EmployeeMapper employeeMapper) {
		this.employeeMapper = employeeMapper;
	}

	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {

		UsernamePasswordToken usernamePasswordToken = (UsernamePasswordToken) token;

		// 获取用户名
		String username = usernamePasswordToken.getUsername();
		// 获取密码
		char[] password = usernamePasswordToken.getPassword();

		Employee employee = employeeMapper.findPWDbyUsername(username);

		// 用戶名不存在
		if (employee == null) {
			throw new UnknownAccountException();
		}
		// 用戶被鎖定
		if (employee.getState() == -1) {
			throw new LockedAccountException();
		}

		// 用户输入的用户名
		Object principals = username;
		// 查出來的密碼
		Object credentials = employee.getPassword();
		// 盐值
		ByteSource credentialsSalt = ByteSource.Util.bytes(employee.getSalt());

		return new SimpleAuthenticationInfo(principals, credentials, credentialsSalt, getName());
	}

	// 通过加盐+加密后获取密码
	public static void main(String[] args) {
		// 算法名称：MD5，SHA-256
		String algorithmName = "MD5";
		// 明文密码
		Object source = "admin1";
		// 盐
		Object salt = ByteSource.Util.bytes("bug");
		// 加密次数
		int hashIterations = 666;
		SimpleHash simpleHash = new SimpleHash(algorithmName, source, salt, hashIterations);
	}

	// 处理授权：判断是否有权限
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
		// 获取当前身份认证成功的对象
		Subject currentUser = SecurityUtils.getSubject();
		String username = (String) currentUser.getPrincipal();
		List<String> list = employeeMapper.findPermissionStringByUsername(username);
		info.addStringPermissions(list);
		return info;
	}

}
