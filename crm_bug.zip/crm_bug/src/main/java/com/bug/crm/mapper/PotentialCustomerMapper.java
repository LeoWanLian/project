package com.bug.crm.mapper;

import com.bug.crm.domain.PotentialCustomer;
/**
 * 
 * @author Administrator
 * 日期:2018年3月29日
 * 类描述:潜在客户信息管理表
 */
public interface PotentialCustomerMapper extends BaseMapper<PotentialCustomer>{

}
