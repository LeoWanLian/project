package com.bug.crm.mapper;

import com.bug.crm.domain.Contract;

/**
 * 合同管理的mapper
 * 
 * @author leowan
 */
public interface ContractMapper extends BaseMapper<Contract> {

}
