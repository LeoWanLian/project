package com.bug.crm.query;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class CutomerTransferQuery extends BaseQuery{
	// 客户
	private Integer customerId;
	//移交人员
	private Integer transUserId;
	// 老市场专员
	private Integer oldSellerId;
	// 新市场专员
	private Integer newSellerId;
	// 起始时间
	private Date beginTime;
	// 结束时间
	private Date endTime;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date getBeginTime() {
		return beginTime;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date getEndTime() {
		return endTime;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getTransUserId() {
		return transUserId;
	}

	public void setTransUserId(Integer transUserId) {
		this.transUserId = transUserId;
	}

	public Integer getOldSellerId() {
		return oldSellerId;
	}

	public void setOldSellerId(Integer oldSellerId) {
		this.oldSellerId = oldSellerId;
	}

	public Integer getNewSellerId() {
		return newSellerId;
	}

	public void setNewSellerId(Integer newSellerId) {
		this.newSellerId = newSellerId;
	}
	
}
