package com.bug.crm.domain;

/**
 * 系统资源管理
 * 
 * @author MARIEROSE
 *
 */
public class Resource extends BaseDomain {
	// `id` bigint(20) NOT NULL AUTO_INCREMENT,
	// `name` varchar(255) NOT NULL,
	// `url` varchar(255) NOT NULL,

	// 名称
	private String name;
	// 资源地址
	private String url;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Resource [name=" + name + ", url=" + url + "]";
	}

}
