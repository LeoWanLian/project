package com.bug.crm.shiro;

import java.util.Date;
import java.util.Objects;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bug.crm.controller.UserContext;
import com.bug.crm.domain.Employee;
import com.bug.crm.domain.SystemLog;
import com.bug.crm.service.ISystemLogService;

@Component
@Aspect
public class LoggerUtils {

	@Autowired
	private ISystemLogService logService;
	//切入点
	@Pointcut("execution(* com.bug.crm.service.I*Service.*(..))")
	public void pointCut() {
	}

	//切入时做什么
	@Around("pointCut()")
	public Object writeLog(ProceedingJoinPoint joinPoint) throws Throwable {
		try {
			Object serviceObj = joinPoint.getTarget();
			if (serviceObj instanceof ISystemLogService) {
				return joinPoint.proceed(); // 执行方法
			}
			Class serviecClz = joinPoint.getTarget().getClass();
			String methodName = joinPoint.getSignature().getName();
			String function = serviecClz.getName() + ":" + methodName;
			String[] parameterNames = ((MethodSignature)joinPoint.getSignature()).getParameterNames();
			
			StringBuilder sb = null;
	        if (Objects.nonNull(parameterNames)) {
	            sb = new StringBuilder();
	            for (int i = 0; i < parameterNames.length; i++) {
	                String value = joinPoint.getArgs()[i] != null ? joinPoint.getArgs()[i].toString() : "null";
	                sb.append(parameterNames[i] + ":" + value + "; ");
	            }
	        }
	        sb = sb == null ? new StringBuilder() : sb;
			SystemLog log = new SystemLog();
			Employee user = UserContext.getLoginUser();
			if (user != null) {
				log.setOpUser(user.getRealName());
				log.setOpTime(new Date());
				log.setOpIp(UserContext.getReuqestIp());
				log.setFunction(function);
				log.setParams(sb.toString());
				logService.save(log);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return joinPoint.proceed(); // 执行方法
	}

}