package com.bug.crm.query;

public class RoleQuery extends BaseQuery {

}
