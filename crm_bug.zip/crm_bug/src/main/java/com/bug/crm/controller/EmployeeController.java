package com.bug.crm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bug.crm.domain.Employee;
import com.bug.crm.query.EmployeeQuery;
import com.bug.crm.query.PageList;
import com.bug.crm.service.IDepartmentService;
import com.bug.crm.service.IEmployeeService;
import com.bug.crm.util.AjaxResult;
import com.bug.crm.util.MD5Util;

/**
 * 部门控制层
 * 
 * @author leowan
 */
@Controller
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	IEmployeeService employeeService;
	@Autowired
	IDepartmentService departmentService;

	// 一个方法显示页面,其他都返回json
	@RequestMapping("/list")
	public String list() {
		return "employee";
	}

	@RequestMapping("/json")
	@ResponseBody
	public PageList json(EmployeeQuery baseQuery) {
		return employeeService.findByQuery(baseQuery);
	}
	@RequestMapping("/json2")
	@ResponseBody
	public PageList json2(EmployeeQuery baseQuery) {
		baseQuery.setRows(Integer.MAX_VALUE);
		return employeeService.findByQuery(baseQuery);
	}

	// 保存方法
	@RequestMapping("/save")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult save(Employee employee) {
		try {
			if (employee.getId() != null) {
				employeeService.update(employee);
			} else {
				employee.setPassword(MD5Util.hash(employee.getPassword()));
				employee.setSalt(MD5Util.SOURCE);
				employeeService.save(employee);
			}
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("保存异常:" + e.getMessage());
		}
	}

	@RequestMapping("/delete")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult delete(Long id) {
		try {
			employeeService.delete(id);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}
	@RequestMapping("/leave")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult leave(Long id) {
		try {
			employeeService.leave(id);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("禁用失敗:" + e.getMessage());
		}
	}
	
	@RequestMapping("/getDepartmentData")
	@ResponseBody
	// 下拉选择部门
	public Object getDepartmentData() {
		return departmentService.getAll();
	}

}
