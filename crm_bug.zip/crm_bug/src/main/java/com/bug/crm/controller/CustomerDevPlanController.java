package com.bug.crm.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bug.crm.domain.CustomerDevPlan;
import com.bug.crm.domain.Employee;
import com.bug.crm.domain.SystemDictionaryItem;
import com.bug.crm.query.CustomerDevPlanQuery;
import com.bug.crm.service.ICustomerDevPlanService;
import com.bug.crm.service.IPotentialCustomerService;
import com.bug.crm.util.AjaxResult;

/**
 *潜在客户开发计划
 * 
 * @author yff
 */
@Controller
@RequestMapping("/customerDevPlan")
public class CustomerDevPlanController {
	@Autowired
	ICustomerDevPlanService customerDevPlanService;
	
	@Autowired
	IPotentialCustomerService potentialCustomerService;

	// 一个方法显示页面,其他都返回json
	@RequestMapping("/list")
	public String list(Model model) {
		return "customerDevPlan";
	}

	/**
	 * 返回列表数据
	 */
	@RequestMapping("/json")
	@ResponseBody
	public Object json(CustomerDevPlanQuery customerDevPlanQuery) {
		return customerDevPlanService.findByQuery(customerDevPlanQuery);
	}

	// 保存方法
	@RequestMapping("/save")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult save(CustomerDevPlan customerDevPlan ,HttpServletRequest request) {
		try {
			if (customerDevPlan.getId() != null) {
				customerDevPlanService.update(customerDevPlan);
			} else {
				customerDevPlan.setInputTime(new Date());//添加当前录入时间
				Employee employee = UserContext.getLoginUser();//获取当前登录用户
				if(employee!=null){
					customerDevPlan.setInputUser(employee);//添加录入员
				}
				customerDevPlanService.save(customerDevPlan);
			}
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("保存异常:" + e.getMessage());
		}
	}

	@RequestMapping("/delete")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult delete(String ids) {
		try {
			//截取字符串
			String[] strArr = ids.split(",");
			//将前台传过来的字符串转成long数组
	        Long[] str2 = new Long[strArr.length];
	        for (int i = 0; i < strArr.length; i++) {
	            str2[i] = Long.valueOf(strArr[i]);
	        }
	        customerDevPlanService.deleteAll(str2);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}

	/**
	 * 获取所有计划实施方式
	 */
	@RequestMapping("/planType")
	@ResponseBody
	public Object getAllplanType() {
		return customerDevPlanService.findSystemDictionaryItemByParent("计划实施方式");

	}
	
	/**
	 * 获取所有潜在客户
	 */
	@RequestMapping("/potentialCustomer")
	@ResponseBody
	public Object getAllPotentialCustomer() {
		return potentialCustomerService.getAll();

	}
	

}
