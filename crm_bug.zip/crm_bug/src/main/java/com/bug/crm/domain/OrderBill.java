package com.bug.crm.domain;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 定金订单
 * 
 * @author leowan
 */
public class OrderBill extends BaseDomain {
	// 定金单号
	private String sn;
	// 签订时间
	private Date signTime;
	// 订单摘要
	private String intro;
	// 定金金额
	private BigDecimal sum;
	// 定金客户(外键)
	private Customer customer;
	// 营销人员(外键)
	private Employee seller;

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
	public Date getSignTime() {
		return signTime;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public void setSignTime(Date signTime) {
		this.signTime = signTime;
	}

	public String getIntro() {
		return intro;
	}

	public void setIntro(String intro) {
		this.intro = intro;
	}

	public BigDecimal getSum() {
		return sum;
	}

	public void setSum(BigDecimal sum) {
		this.sum = sum;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Employee getSeller() {
		return seller;
	}

	public void setSeller(Employee seller) {
		this.seller = seller;
	}

	@Override
	public String toString() {
		return "OrderBill [sn=" + sn + ", signTime=" + signTime + ", intro=" + intro + "]";
	}

}
