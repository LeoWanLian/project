package com.bug.crm.mapper;

import com.bug.crm.domain.CutomerTransfer;
/**
 * 
 * @author Administrator
 * 日期:2018年3月29日
 * 类描述:（潜在）客户开发计划
 */
public interface CustomerTransferMapper extends BaseMapper<CutomerTransfer>{
	
}
