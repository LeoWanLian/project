package com.bug.crm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bug.crm.domain.ContractItem;
import com.bug.crm.query.ContractItemQuery;
import com.bug.crm.query.PageList;
import com.bug.crm.service.ICustomerService;
import com.bug.crm.service.IEmployeeService;
import com.bug.crm.service.IContractItemService;
import com.bug.crm.util.AjaxResult;

/**
 * 定金订单控制层
 * 
 * @author leowan
 */
@Controller
@RequestMapping("/contractItem")
public class ContractItemController {
	@Autowired
	IContractItemService contractItemService;
	@Autowired
	ICustomerService customerService;
	@Autowired
	IEmployeeService employeeService;

	// 一个方法显示页面,其他都返回json
	@RequestMapping("/list")
	public String list() {
		return "contractItem";
	}

	@RequestMapping("/json")
	@ResponseBody
	public PageList json(ContractItemQuery baseQuery) {
		return contractItemService.findByQuery(baseQuery);
	}

	// 保存方法
	@RequestMapping("/save")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult save(ContractItem contractItem) {
		try {
			if (contractItem.getId() != null) {
				contractItemService.update(contractItem);
			} else {
				contractItemService.save(contractItem);
			}
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("保存异常:" + e.getMessage());
		}
	}

	@RequestMapping("/delete")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult delete(Long id) {
		try {
			contractItemService.delete(id);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}
	
	@RequestMapping("/getCustomerData")
	@ResponseBody
	// 下拉选择客户信息
	public Object getCustomerData() {
		return customerService.getAll();
	}
	
	@RequestMapping("/getSellerrData")
	@ResponseBody
	// 下拉选择销售人员信息
	public Object getSellerrData() {
		return employeeService.getAll();
	}
	
	@RequestMapping("/printItem")
	@ResponseBody
	// 打印数据
	public Object printItem(Long contractId) {
		
		ContractItemQuery baseQuery = new ContractItemQuery();
		baseQuery.setContractId(contractId);
		PageList list = contractItemService.findByQuery(baseQuery);
		
		return list;
	}
	
}
