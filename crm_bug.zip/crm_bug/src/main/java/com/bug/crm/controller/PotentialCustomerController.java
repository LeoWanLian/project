package com.bug.crm.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bug.crm.domain.Customer;
import com.bug.crm.domain.Employee;
import com.bug.crm.domain.PotentialCustomer;
import com.bug.crm.domain.SystemDictionaryItem;
import com.bug.crm.query.PotentialCustomerQuery;
import com.bug.crm.service.IEmployeeService;
import com.bug.crm.service.IPotentialCustomerService;
import com.bug.crm.util.AjaxResult;

/**
 * 潜在客户控制层
 * 
 * @author yff
 */
@Controller
@RequestMapping("/potentialCustomer")
public class PotentialCustomerController {
	@Autowired
	IPotentialCustomerService potentialCustomerService;
	@Autowired
	IEmployeeService employeeService;
	// 一个方法显示页面,其他都返回json
	@RequestMapping("/list")
	public String list(Model model) {
		return "potentialCustomer";
	}

	/**
	 * 返回列表数据
	 */
	@RequestMapping("/json")
	@ResponseBody
	public Object json(PotentialCustomerQuery potentialCustomerQuery) {
		return potentialCustomerService.findByQuery(potentialCustomerQuery);
	}
	/**
	 * combtree查询
	 */
	@RequestMapping("/json2")
	@ResponseBody
	public Object json2(PotentialCustomerQuery potentialCustomerQuery) {
		potentialCustomerQuery.setRows(Integer.MAX_VALUE);
		return potentialCustomerService.findByQuery(potentialCustomerQuery);
	}

	// 保存方法
	@RequestMapping("/save")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult save(PotentialCustomer potentialCustomer ,HttpServletRequest request) {
		try {
			if (potentialCustomer.getId() != null) {
				potentialCustomerService.update(potentialCustomer);
			} else {
				potentialCustomer.setInputTime(new Date());//添加当前录入时间
				Employee employee = UserContext.getLoginUser();//获取当前登录用户
				if(employee!=null){
					potentialCustomer.setInputUser(employee);//添加录入员
				}
				potentialCustomerService.save(potentialCustomer);
			}
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("保存异常:" + e.getMessage());
		}
	}

	@RequestMapping("/delete")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult delete(String ids) {
		
		try {
			//截取字符串
			String[] strArr = ids.split(",");
			//将前台传过来的字符串转成long数组
	        Long[] str2 = new Long[strArr.length];
	        for (int i = 0; i < strArr.length; i++) {
	            str2[i] = Long.valueOf(strArr[i]);
	        }
			potentialCustomerService.deleteAll(str2);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}
	/**
	 * 潜在客户升级
	 */
	@RequestMapping("/upgrade")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult upgrade(Customer customer,HttpServletRequest request) {
		
		try {
			Employee employee = (Employee)request.getSession().getAttribute("user_in_session");//获取当前登录用户
			if(employee!=null){
				customer.setInputUser(employee);//添加录入员
			}
			customer.setInputTime(new Date());
			potentialCustomerService.upgrade(customer);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}

	/**
	 * 客户来源
	 */
	@RequestMapping("/customerSource")
	@ResponseBody
	public Object customerSource() {

		return potentialCustomerService.findSystemDictionaryItemByParent("客户来源");

	}
	/**
	 *录入员
	 */
	@RequestMapping("/inputUser")
	@ResponseBody
	public Object getInputUser() {

		return employeeService.getAll();

	}
	/**
	 * 获取所有有潜在客户
	 */
	@RequestMapping("/all")
	@ResponseBody
	public Object getAll() {
		
		return potentialCustomerService.getAll();
		
	}

}
