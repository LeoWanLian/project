package com.bug.crm.query;

public class SystemMenuQuery extends BaseQuery{

}
