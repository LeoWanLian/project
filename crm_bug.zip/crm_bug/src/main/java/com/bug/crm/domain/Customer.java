package com.bug.crm.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
/**
 * 
 * @author 余非凡
 * 日期:2018年3月29日
 * 类描述:客户信息管理表模型
 */
public class Customer extends BaseDomain{
	
	private String name;//客户姓名
	private Integer age;//客户年龄
	private Boolean gender;//客户性别
	private String tel;//客户电话
	private String email;//客户邮箱
	private String qq;//qq
	private String wechat;//微信
	private Employee seller;//营销人员
	private SystemDictionaryItem job;//数据字典明细:工作
	private SystemDictionaryItem salaryLevel;//数据字典明细;收入水平
	private SystemDictionaryItem customerSource;//数据字典明细:客户来源
	private Employee inputUser;//创建人:自动填入当前登录用户，用户不可更改
	private Date inputTime; //创建时间:当前系统时间
	private Integer state=0;//客户状态 0  正常  -1 资源池
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Boolean getGender() {
		return gender;
	}
	public void setGender(Boolean gender) {
		this.gender = gender;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getQq() {
		return qq;
	}
	public void setQq(String qq) {
		this.qq = qq;
	}
	public String getWechat() {
		return wechat;
	}
	public void setWechat(String wechat) {
		this.wechat = wechat;
	}
	public Employee getSeller() {
		return seller;
	}
	public void setSeller(Employee seller) {
		this.seller = seller;
	}
	public SystemDictionaryItem getJob() {
		return job;
	}
	public void setJob(SystemDictionaryItem job) {
		this.job = job;
	}
	public SystemDictionaryItem getSalaryLevel() {
		return salaryLevel;
	}
	public void setSalaryLevel(SystemDictionaryItem salaryLevel) {
		this.salaryLevel = salaryLevel;
	}
	public SystemDictionaryItem getCustomerSource() {
		return customerSource;
	}
	public void setCustomerSource(SystemDictionaryItem customerSource) {
		this.customerSource = customerSource;
	}
	public Employee getInputUser() {
		return inputUser;
	}
	public void setInputUser(Employee inputUser) {
		this.inputUser = inputUser;
	}
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
	public Date getInputTime() {
		return inputTime;
	}
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public void setInputTime(Date inputTime) {
		this.inputTime = inputTime;
	}
	
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", age=" + age + ", gender=" + gender + ", tel=" + tel + ", email=" + email
				+ ", qq=" + qq + ", wechat=" + wechat + ", inputTime=" + inputTime + "]";
	}
	
	
	
	
}
