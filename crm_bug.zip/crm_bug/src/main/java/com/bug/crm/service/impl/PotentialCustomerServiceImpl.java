package com.bug.crm.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bug.crm.domain.Customer;
import com.bug.crm.domain.PotentialCustomer;
import com.bug.crm.mapper.CustomerMapper;
import com.bug.crm.mapper.PotentialCustomerMapper;
import com.bug.crm.service.IPotentialCustomerService;

/**
 * 合同明细的service层实现,必须有@service注解
 * 
 * @author leowan
 */
@Service
public class PotentialCustomerServiceImpl extends BaseServiceImpl<PotentialCustomer> implements IPotentialCustomerService {
	@Autowired
	private PotentialCustomerMapper potentialCustomerMapper;
	@Autowired
	private CustomerMapper customerMapper;
	
	/**
	 * 潜在客户升级
	 */
	@Transactional
	@Override
	public void upgrade(Customer customer) {
		//在潜在客户表中删除 这条潜在客户信息
		potentialCustomerMapper.delete(customer.getId());
		//设置id为空 ,调用save 方法时为添加
		customer.setId(null);
		//在customer表中保存 客户信息
		customerMapper.save(customer);
		
	}
	
}
