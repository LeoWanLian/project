package com.bug.crm.query;

/**
 * 封装查询条件
 * 
 * @author LeoWan
 *
 */
public class BaseQuery {
	// 关键字查询.后续后台远程分页需要使用q
	// private String keyWord;
	private String q;
	// easyui 传递分页参数 page为当前页,rows为每页的条数
	private int page = 1;
	private int rows = 10;

	private String order = "asc";
	private String sort = "o.id";

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

	public String getSort() {
		if ("customer".equals(sort)) {
			return "o.customer_id";
		} else if ("seller".equals(sort)) {
			return "o.seller_id";
		}
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

	public int getBegin() {
		return (page - 1) * rows;
	}

	public int getEnd() {
		return rows;
	}

	public String getQ() {
		return q;
	}

	public void setQ(String q) {
		this.q = q;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	@Override
	public String toString() {
		return "BaseQuery [q=" + q + ", page=" + page + ", rows=" + rows + ", order=" + order + ", sort=" + sort + "]";
	}

}
