package com.bug.crm.service;

import java.util.List;

import com.bug.crm.domain.Department;

/**
 * 部门管理service层接口
 * 
 * @author leowan
 */
public interface IDepartmentService extends IBaseService<Department> {

	List<Department> getTreeData();


}
