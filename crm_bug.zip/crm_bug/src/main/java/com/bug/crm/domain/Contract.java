package com.bug.crm.domain;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 合同 组合关系 (一方)
 * 
 * @author leowan
 */
public class Contract extends BaseDomain {
	// 合同单号
	private String sn;
	// 合同摘要
	private String intro;
	// 签订时间
	private Date signTime;
	// 合同金额
	private BigDecimal sum;
	// 合同客户(外键)
	private Customer customer;
	// 营销人员(外键)
	private Employee seller;
	// 付款详情, 合同明细 (外键多方)
	private List<ContractItem> items;
	
	private String flag;

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getIntro() {
		return intro;
	}

	public void setIntro(String intro) {
		this.intro = intro;
	}

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date getSignTime() {
		return signTime;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public void setSignTime(Date signTime) {
		this.signTime = signTime;
	}

	public BigDecimal getSum() {
		return sum;
	}

	public void setSum(BigDecimal sum) {
		this.sum = sum;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Employee getSeller() {
		return seller;
	}

	public void setSeller(Employee seller) {
		this.seller = seller;
	}

	public List<ContractItem> getItems() {
		return items;
	}

	public void setItems(List<ContractItem> items) {
		this.items = items;
	}

	@Override
	public String toString() {
		return "Contract [sn=" + sn + ", intro=" + intro + ", signTime=" + signTime + ", sum=" + sum + ", customer="
				+ customer + ", seller=" + seller + ", items=" + items.size() + "]";
	}

	
}
