package com.bug.crm.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 
 * @author Administrator 日期:2018年3月29日 类描述:潜在客户管理
 */
public class PotentialCustomer extends BaseDomain {
	private SystemDictionaryItem customerSource;// 数据字典明细:客户来源
	private String name;// 客户潜在客户名
	private Integer successRate;// 成为客户的成功几率
	private String remark;// 客户描述--对潜在客户的简要备注
	private String linkMan;// 联系人
	private String linkManTel;// 联系电话
	private Employee inputUser;// 创建人 ---自动填入当前登录用户，用户不可更改
	private Date inputTime;// 创建时间当前系统时间

	public SystemDictionaryItem getCustomerSource() {
		return customerSource;
	}

	public void setCustomerSource(SystemDictionaryItem customerSource) {
		this.customerSource = customerSource;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getSuccessRate() {
		return successRate;
	}

	public void setSuccessRate(Integer successRate) {
		this.successRate = successRate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getLinkMan() {
		return linkMan;
	}

	public void setLinkMan(String linkMan) {
		this.linkMan = linkMan;
	}

	public String getLinkManTel() {
		return linkManTel;
	}

	public void setLinkManTel(String linkManTel) {
		this.linkManTel = linkManTel;
	}

	public Employee getInputUser() {
		return inputUser;
	}

	public void setInputUser(Employee inputUser) {
		this.inputUser = inputUser;
	}
	@JsonFormat(pattern="yyyy-MM-dd ",timezone="GMT+8")
	public Date getInputTime() {
		return inputTime;
	}
	@DateTimeFormat(pattern="yyyy-MM-dd")
	public void setInputTime(Date inputTime) {
		this.inputTime = inputTime;
	}

	@Override
	public String toString() {
		return "PotentialCustomer [name=" + name + "]";
	}

}
