package com.bug.crm.mapper;

import java.util.List;

import com.bug.crm.domain.Department;

/**
 * 部门管理的mapper
 * 
 * @author leowan
 */
public interface DepartmentMapper extends BaseMapper<Department> {
	List<Department> getTreeData();

}
