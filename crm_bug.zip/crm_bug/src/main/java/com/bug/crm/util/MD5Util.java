package com.bug.crm.util;

import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.util.ByteSource;

//数据库密码加密保存
public class MD5Util {
	// 加密次数
	public static final int HASHNUM = 666;
	// 盐值
	public static final String SOURCE = "bug";

	/**
	 * 加密算法
	 * 
	 * @param content
	 * @return
	 */
	public static String hash(String content) {
		ByteSource byteSource = ByteSource.Util.bytes(SOURCE);
		SimpleHash simpleHash = new SimpleHash("md5", content, byteSource, HASHNUM);
		return simpleHash.toString();
	}
	
}
