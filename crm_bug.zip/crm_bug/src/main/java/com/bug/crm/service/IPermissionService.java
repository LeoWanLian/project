package com.bug.crm.service;

import com.bug.crm.domain.Permission;

/**
 * 部门管理service层接口
 *
 */
public interface IPermissionService extends IBaseService<Permission> {
	
}
