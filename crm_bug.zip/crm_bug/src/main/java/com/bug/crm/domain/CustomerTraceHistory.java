package com.bug.crm.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
/**
 * 
 * @author Administrator
 * 日期:2018年3月29日
 * 类描述:客户跟进历史
 */
public class CustomerTraceHistory extends BaseDomain{
	
	private Customer customer;//客户--跟进的哪一个客户
	private Employee traceUser;//跟进人(跟进该客户的员工)
	private Date traceTime;//跟进时间
	private SystemDictionaryItem traceType;//数据字典明细: 跟进方式(邀约上门、电话、短信、邮件等)
	private Integer traceResult; //跟进效果(优,中,差)
	private String title;//跟进主题
	private String remark;//跟进细节(如：QQ聊天记录等)
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Employee getTraceUser() {
		return traceUser;
	}
	public void setTraceUser(Employee traceUser) {
		this.traceUser = traceUser;
	}
	@JsonFormat(pattern="yyyy-MM-dd ",timezone="GMT+8")
	public Date getTraceTime() {
		return traceTime;
	}
	@DateTimeFormat(pattern = "yyyy-MM-dd ")
	public void setTraceTime(Date traceTime) {
		this.traceTime = traceTime;
	}
	public SystemDictionaryItem getTraceType() {
		return traceType;
	}
	public void setTraceType(SystemDictionaryItem traceType) {
		this.traceType = traceType;
	}
	public Integer getTraceResult() {
		return traceResult;
	}
	public void setTraceResult(Integer traceResult) {
		this.traceResult = traceResult;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Override
	public String toString() {
		return "CustomerTraceHistory [getId()=" + getId() + "]";
	}
	
	
}
