package com.bug.crm.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.bug.crm.domain.Customer;
import com.bug.crm.domain.Employee;
import com.bug.crm.query.CustomerQuery;
import com.bug.crm.service.ICustomerService;
import com.bug.crm.service.IEmployeeService;
import com.bug.crm.util.AjaxResult;

/**
 * 客户页面
 * 
 * @author yff
 */
@Controller
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	ICustomerService customerService;

	@Autowired
	IEmployeeService employeeService;

	// 一个方法显示页面,其他都返回json
	@RequestMapping("/list")
	public String list(Model model) {
		return "customer";
	}

	// 显示资源池页面
	@RequestMapping("/list2")
	public String list2(Model model) {
		return "poolCustomer";
	}

	/**
	 * 返回列表数据
	 */
	@RequestMapping("/json")
	@ResponseBody
	public Object json(CustomerQuery customerQuery) {
		return customerService.findByQuery(customerQuery);
	}

	/**
	 * 资源池客户查询
	 */
	@RequestMapping("/json3")
	@ResponseBody
	public Object json3(CustomerQuery customerQuery) {
		customerQuery.setSign(1);// 表示查询资源池
		return customerService.findByQuery(customerQuery);
	}

	@RequestMapping("/json2")
	@ResponseBody
	public Object json2(CustomerQuery customerQuery) {
		customerQuery.setRows(Integer.MAX_VALUE);
		return customerService.findByQuery(customerQuery);
	}

	// 保存方法
	@RequestMapping("/save")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult save(Customer customer, HttpServletRequest request) {
		try {
			if (customer.getId() != null) {

				customerService.update(customer);
			} else {// 新增保存

				customer.setInputTime(new Date());// 添加当前录入时间
				Employee employee = UserContext.getLoginUser();//  获取当前登录用户
				if (employee != null) {
					customer.setInputUser(employee);// 添加录入员
				}
				customerService.save(customer);
			}
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("保存异常:" + e.getMessage());
		}
	}

	@RequestMapping("/delete")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult delete(String ids) {
		try {
			// 截取字符串
			String[] strArr = ids.split(",");
			// 将前台传过来的字符串转成long数组
			Long[] str2 = new Long[strArr.length];
			for (int i = 0; i < strArr.length; i++) {
				str2[i] = Long.valueOf(strArr[i]);
			}
			customerService.deleteAll(str2);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}

	/**
	 * 将顾客放入资源池
	 */
	@RequestMapping("/putInPool")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult putInPool(String ids) {
		try {
			// 截取字符串
			String[] strArr = ids.split(",");
			// 将前台传过来的字符串转成long数组
			Long[] str2 = new Long[strArr.length];
			for (int i = 0; i < strArr.length; i++) {
				str2[i] = Long.valueOf(strArr[i]);
			}
			customerService.putInPool(str2);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}

	/**
	 * 将资源池客户转为客户
	 */
	@RequestMapping("/removePool")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult removePool(String ids) {
		try {
			// 截取字符串
			String[] strArr = ids.split(",");
			// 将前台传过来的字符串转成long数组
			Long[] str2 = new Long[strArr.length];
			for (int i = 0; i < strArr.length; i++) {
				str2[i] = Long.valueOf(strArr[i]);
			}
			customerService.removePool(str2);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}

	/**
	 * 获取所有职业
	 */
	@RequestMapping("/job")
	@ResponseBody
	public Object getAlljob() {
		return customerService.findSystemDictionaryItemByParent("职业");

	}

	/**
	 * 获取所有收入水平
	 */
	@RequestMapping("/salaryLevel")
	@ResponseBody
	public Object getAllsalaryLevel() {
		return customerService.findSystemDictionaryItemByParent("收入水平");

	}

	/**
	 * 获取所有客户来源
	 */
	@RequestMapping("/customerSource")
	@ResponseBody
	public Object getAllcustomerSource() {
		return customerService.findSystemDictionaryItemByParent("客户来源");

	}

	/**
	 * 获取所有营销人员
	 */
	@RequestMapping("/seller")
	@ResponseBody
	public Object getAllPotentialCustomer() {
		return employeeService.getAll();

	}

	@RequestMapping("/download")
	public void get(CustomerQuery customerQuery, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// 第一行：设置建议的下载文件名
		response.setHeader("Content-Disposition", "filename=客户数据.xlsx");
		// 第二行：设置文件名的类型
		// struts.xml:<param
		// name="contentType">application/vnd.openxmlformats-officedocument.spreadsheetml.sheet</param>
		response.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		// 准备文件
		// String webapp = request.getServletContext().getRealPath("/");
		// File file = new File(webapp, "xxxx.xlsx");
		// FileInputStream inputStream = new FileInputStream(file);
		InputStream inputStream = customerService.downloadExcel(customerQuery);
		IOUtils.copy(inputStream, response.getOutputStream());
	}
	@RequestMapping("/downTemp")
	public void downTemp(CustomerQuery customerQuery, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// 第一行：设置建议的下载文件名
		response.setHeader("Content-Disposition", "filename=temp.xlsx");
		// 第二行：设置文件名的类型
		// struts.xml:<param
		// name="contentType">application/vnd.openxmlformats-officedocument.spreadsheetml.sheet</param>
		response.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
//		 准备文件
		 String webapp = request.getServletContext().getRealPath("/");
		 File file = new File(webapp, "客户数据模板.xlsx");
		 FileInputStream inputStream = new FileInputStream(file);
		IOUtils.copy(inputStream, response.getOutputStream());
	}

	@RequestMapping("/upload")
	@ResponseBody
	public Object upload(MultipartFile upload) {
		try {
			
			customerService.upload(upload);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("导入异常:" + e.getMessage());
		}
		
	}

}
