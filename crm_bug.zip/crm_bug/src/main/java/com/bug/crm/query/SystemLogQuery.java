package com.bug.crm.query;

public class SystemLogQuery extends BaseQuery{

}
