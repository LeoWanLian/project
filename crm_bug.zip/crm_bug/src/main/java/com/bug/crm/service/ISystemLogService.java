package com.bug.crm.service;

import com.bug.crm.domain.SystemLog;

/**
 * 部门管理service层接口
 *
 */
public interface ISystemLogService extends IBaseService<SystemLog> {
	
}
