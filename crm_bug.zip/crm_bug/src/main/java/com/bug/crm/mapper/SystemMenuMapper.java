package com.bug.crm.mapper;

import com.bug.crm.domain.SystemMenu;

/**
 *	部门管理的mapper 
 *
 */
public interface SystemMenuMapper extends BaseMapper<SystemMenu>{
	
}
