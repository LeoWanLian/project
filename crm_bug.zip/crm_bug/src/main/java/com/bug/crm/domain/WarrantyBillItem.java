package com.bug.crm.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 保修订单明细 组合关系 (多方)
 * 
 * @author leowan
 */
public class WarrantyBillItem extends BaseDomain {
	// 保修时间
	private Date warrantyTime;
	// 保修内容
	private String warrantyDetail;
	// 维修状态,是否解决 0待解决,1已解决，-1异常
	private Integer solve;
	// 所属保修单 (组合一方)
	private WarrantyBill bill;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date getWarrantyTime() {
		return warrantyTime;
	}
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public void setWarrantyTime(Date warrantyTime) {
		this.warrantyTime = warrantyTime;
	}

	public String getWarrantyDetail() {
		return warrantyDetail;
	}

	public void setWarrantyDetail(String warrantyDetail) {
		this.warrantyDetail = warrantyDetail;
	}

	public Integer getSolve() {
		return solve;
	}

	public void setSolve(Integer solve) {
		this.solve = solve;
	}

	public WarrantyBill getBill() {
		return bill;
	}

	public void setBill(WarrantyBill bill) {
		this.bill = bill;
	}


}
