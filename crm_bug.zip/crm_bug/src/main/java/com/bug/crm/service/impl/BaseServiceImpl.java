package com.bug.crm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bug.crm.domain.SystemDictionaryItem;
import com.bug.crm.mapper.BaseMapper;
import com.bug.crm.query.BaseQuery;
import com.bug.crm.query.PageList;
import com.bug.crm.service.IBaseService;

/**
 * service层的基础实现类. 基类控制事务,子类就不需要管事务
 * 
 * @author leowan
 * @param <T>
 */
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class BaseServiceImpl<T> implements IBaseService<T> {
	@Autowired
	BaseMapper<T> baseMapper;

	@Transactional
	public void save(T t) {
		baseMapper.save(t);
	}

	@Transactional
	public void update(T t) {
		baseMapper.update(t);
	}

	@Transactional
	public void delete(Long id) {
		baseMapper.delete(id);
	}

	public T get(Long id) {

		return baseMapper.get(id);
	}

	public List<T> getAll() {

		return baseMapper.getAll();
	}

	@Override
	public PageList findByQuery(BaseQuery baseQuery) {
		int total = baseMapper.findTotalByQuery(baseQuery);
		if (total == 0) {
			return new PageList();
		}
		List<T> rows = baseMapper.findLimitByQuery(baseQuery);
		return new PageList(total, rows);
	}
	/**
	 * 根据数据字典父类型名称  获取数据字典明细
	 */
	@Override
	public List<SystemDictionaryItem> findSystemDictionaryItemByParent(String typeName) {
		
		return baseMapper.findSystemDictionaryItemByParent(typeName);
	}

	//批量删除
	@Transactional
	@Override
	public void deleteAll(Long[] ids) {
		baseMapper.deleteAll(ids);
	}

}
