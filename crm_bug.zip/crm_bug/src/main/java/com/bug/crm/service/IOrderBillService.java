package com.bug.crm.service;

import com.bug.crm.domain.OrderBill;

/**
 * 定金订单service层接口
 * 
 * @author leowan
 */
public interface IOrderBillService extends IBaseService<OrderBill> {


}
