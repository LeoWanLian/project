package com.bug.crm.mapper;

import com.bug.crm.domain.SystemDictionaryItem;

/**
 *	部门管理的mapper 
 *
 */
public interface SystemDictionaryItemMapper extends BaseMapper<SystemDictionaryItem>{
	
}
