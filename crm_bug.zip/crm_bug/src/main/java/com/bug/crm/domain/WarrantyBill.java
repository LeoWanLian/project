package com.bug.crm.domain;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 保修订单 组合关系 (一方)
 * 
 * @author leowan
 */
public class WarrantyBill extends BaseDomain {
	// 保修单号
	private String sn;
	// 质保到期时间
	private Date warrantyDate;
	// 保修客户(外键)
	private Customer customer;
	// 保修单明细 (外键 组合多方)
	private List<WarrantyBillItem> items;

	private String flag;

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date getWarrantyDate() {
		return warrantyDate;
	}
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public void setWarrantyDate(Date warrantyDate) {
		this.warrantyDate = warrantyDate;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<WarrantyBillItem> getItems() {
		return items;
	}

	public void setItems(List<WarrantyBillItem> items) {
		this.items = items;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	@Override
	public String toString() {
		return "WarrantyBill [sn=" + sn + ", warrantyDate=" + warrantyDate + "]";
	}

}
