package com.bug.crm.domain;

/**
 * 基类domain
 * 
 * @author MARIEROSE
 *
 */
public class BaseDomain {
	// 主键
	private Long id;
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}
