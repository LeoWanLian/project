package com.bug.crm.controller;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bug.crm.util.AjaxResult;

/**
 * 部门控制层
 * 
 * @author leowan
 */
@Controller
public class LoginController {

	// 显示页面
	@RequestMapping(method = RequestMethod.GET, name = "/login")
	public String get() {
		return "login";
	}

	// 處理登錄
	@RequestMapping(method = RequestMethod.POST, name = "/login")
	@ResponseBody
	public AjaxResult post(String username, String password) {
		// 获取当前身份认证成功的对象
		Subject currentUser = SecurityUtils.getSubject();

		if (!currentUser.isAuthenticated()) {
			// 封装用户名和密码令牌对象
			UsernamePasswordToken token = new UsernamePasswordToken(username, password);
			try {
				// 进行身份认证
				currentUser.login(token);
			} catch (UnknownAccountException uae) {
				return new AjaxResult("--------------无效用戶--------------");
			} catch (IncorrectCredentialsException ice) {
				return new AjaxResult("--------------密码错误--------------");
			} catch (LockedAccountException lae) {
				return new AjaxResult("--------------账户锁定--------------");
			} catch (AuthenticationException ae) {
				return new AjaxResult("--------------登录失败--------------" + ae.getMessage());
			}
		}

		return new AjaxResult();
	}

	// 注销
	@RequestMapping(name = "/logout")
	public String logout() {
		// 获取当前身份认证成功的对象
		Subject currentUser = SecurityUtils.getSubject();
		// 注销
		currentUser.logout();
		return "login";
	}

}
