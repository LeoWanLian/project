package com.bug.crm.mapper;

import java.util.List;

import com.bug.crm.domain.Customer;
import com.bug.crm.domain.OrderBill;

/**
 * 定金订单的mapper
 * 
 * @author leowan
 */
public interface OrderBillMapper extends BaseMapper<OrderBill> {

}
