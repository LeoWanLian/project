package com.bug.crm.service;

import java.util.List;

import com.bug.crm.domain.SystemDictionaryItem;
import com.bug.crm.query.BaseQuery;
import com.bug.crm.query.PageList;

/**
 * 抽取的基础接口,提供公共的CRUD
 * 
 * @author leowan
 * @param <T>
 */
public interface IBaseService<T> {
	void save(T t);

	void update(T t);

	void delete(Long id);

	T get(Long id);

	List<T> getAll();
	
	PageList findByQuery(BaseQuery baseQuery);
	/**
	 * 根据数据字典父类型名称  获取数据字典明细
	 */
	List<SystemDictionaryItem> findSystemDictionaryItemByParent(String typeName);
	//批量删除
	void deleteAll(Long[] ids);
}
