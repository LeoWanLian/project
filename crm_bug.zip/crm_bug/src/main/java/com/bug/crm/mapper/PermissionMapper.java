package com.bug.crm.mapper;

import com.bug.crm.domain.Permission;

/**
 *	部门管理的mapper 
 *
 */
public interface PermissionMapper extends BaseMapper<Permission>{
	
}
