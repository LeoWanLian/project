package com.bug.crm.service;

import com.bug.crm.domain.SystemMenu;

/**
 * 部门管理service层接口
 *
 */
public interface ISystemMenuService extends IBaseService<SystemMenu> {
	
}
