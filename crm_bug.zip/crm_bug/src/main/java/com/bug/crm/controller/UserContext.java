package com.bug.crm.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.bug.crm.domain.Employee;
import com.bug.crm.mapper.EmployeeMapper;

/**
 * 
 * 用户的上下文：实例方法注入bean到类的静态属性
 *
 */
@Component
// 组件的配置，把当前类交给spring管理
// <bean id="userContext" class="cn.itsource.crm.shiro.UserContext">
public class UserContext {

	static EmployeeMapper employeeMapper;

	@Autowired
	// 静态方法是不能注入mapper，所有这里写了一个实例方法，由spring注入mapper，然后赋值给静态变量
	public void setEmployeeMapper(EmployeeMapper employeeMapper) {
		UserContext.employeeMapper = employeeMapper;
	}


	public static boolean isAdmin() {
		// 获取当前身份认证成功的对象
		Subject currentUser = SecurityUtils.getSubject();
		String username = (String) currentUser.getPrincipal();
		List<String> list = employeeMapper.findRoleByUsername(username);
		for (String sn : list) {
			if (sn.endsWith("Admin")) {
				// 是否是经理或者管理员
				return true;
			}
		}
		return false;
	}

	public static Employee getLoginUser() {
		// 当前登录的用户，类似于HttpSession存储的employee用户
		Subject currentUser = SecurityUtils.getSubject();
		String username = (String) currentUser.getPrincipal();
		Employee employee = employeeMapper.findPWDbyUsername(username);
		return employee;
	}

	public static String getReuqestIp() {
		HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest(); 		
		String addr = request.getRemoteAddr();

		return addr;
	}

}
