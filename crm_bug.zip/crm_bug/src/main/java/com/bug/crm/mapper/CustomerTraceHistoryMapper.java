package com.bug.crm.mapper;

import com.bug.crm.domain.CustomerTraceHistory;
/**
 * 
 * @author Administrator
 * 日期:2018年3月29日
 * 类描述:客户跟进历史
 */
public interface CustomerTraceHistoryMapper extends BaseMapper<CustomerTraceHistory>{
	
}
