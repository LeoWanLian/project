package com.bug.crm.mapper;

import com.bug.crm.domain.WarrantyBillItem;

/**
 * 保修订单的mapper
 * 
 * @author leowan
 */
public interface WarrantyBillItemMapper extends BaseMapper<WarrantyBillItem> {

}
