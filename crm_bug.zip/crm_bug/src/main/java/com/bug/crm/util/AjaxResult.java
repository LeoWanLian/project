package com.bug.crm.util;

/**
 * 处理ajax请求的返回结果.
 * 
 * @author leowan
 */
public class AjaxResult {
	private boolean success = true;
	private String message = "操作成功";

	// 默认返回操作成功.
	public AjaxResult() {
	}

	// 如果操作失败,返回的json为false
	public AjaxResult(String message) {
		this.success = false;
		this.message = message;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
