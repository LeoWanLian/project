package com.bug.crm.mapper;

import com.bug.crm.domain.SystemLog;

/**
 *	部门管理的mapper 
 *
 */
public interface SystemLogMapper extends BaseMapper<SystemLog>{
	
}
