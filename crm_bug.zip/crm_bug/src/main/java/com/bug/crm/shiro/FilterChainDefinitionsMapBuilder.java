package com.bug.crm.shiro;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.bug.crm.domain.Permission;
import com.bug.crm.mapper.PermissionMapper;

/**
 * 
 * 动态获取权限字符串的方法不能写为static方法，后面需要访问数据库，需要注入mapper
 *
 */
public class FilterChainDefinitionsMapBuilder {

	@Autowired
	PermissionMapper permissionMapper;

	/**
	 * 返回/department/list=perms[department:*]这种结构的数据
	 */
	public Map<String, String> buider() {
		Map<String, String> map = new LinkedHashMap<String, String>();
		map.put("/login", "anon");
		map.put("/static/**", "anon");
		map.put("/logout", "logout");

		List<Permission> list = permissionMapper.getAll();
		for (Permission permission : list) {
			// 获取访问地址
			String url = permission.getUrl();
			// 获取权限字符串，并且拼接成shiro需要的格式
			String source = "CRMPerms[" + permission.getResource() + "]";
			map.put(url, source);
		}
	
		map.put("/**", "authc");
		return map;
	}
}
