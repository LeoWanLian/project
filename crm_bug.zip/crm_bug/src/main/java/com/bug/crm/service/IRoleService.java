package com.bug.crm.service;

import com.bug.crm.domain.Role;

/**
 * 部门管理service层接口
 *
 */
public interface IRoleService extends IBaseService<Role> {
	// 自己实现级联删除、级联保存、级联修改的效果
	void delete(Long id);

	void save(Role role);

	void update(Role role);
}
