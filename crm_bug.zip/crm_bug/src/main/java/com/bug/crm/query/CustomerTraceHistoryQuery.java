package com.bug.crm.query;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class CustomerTraceHistoryQuery extends BaseQuery{
		// 跟进方式
		private Integer traceTypeId;
		//跟进效果
		private Integer traceResult;
		// 跟进客户
		private Integer customerId;
		// 跟进人
		private Integer traceUserId;
		// 起始时间
		private Date beginTime;
		// 结束时间
		private Date endTime;

		@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
		public Date getBeginTime() {
			return beginTime;
		}

		@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
		public void setBeginTime(Date beginTime) {
			this.beginTime = beginTime;
		}

		@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
		public Date getEndTime() {
			return endTime;
		}

		@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
		public void setEndTime(Date endTime) {
			this.endTime = endTime;
		}

		public Integer getTraceTypeId() {
			return traceTypeId;
		}

		public void setTraceTypeId(Integer traceTypeId) {
			this.traceTypeId = traceTypeId;
		}

		public Integer getTraceResult() {
			return traceResult;
		}

		public void setTraceResult(Integer traceResult) {
			this.traceResult = traceResult;
		}

		public Integer getCustomerId() {
			return customerId;
		}

		public void setCustomerId(Integer customerId) {
			this.customerId = customerId;
		}

		public Integer getTraceUserId() {
			return traceUserId;
		}

		public void setTraceUserId(Integer traceUserId) {
			this.traceUserId = traceUserId;
		}
		
}
