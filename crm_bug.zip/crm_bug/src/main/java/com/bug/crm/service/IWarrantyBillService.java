package com.bug.crm.service;

import com.bug.crm.domain.WarrantyBill;

/**
 * 定金订单service层接口
 * 
 * @author leowan
 */
public interface IWarrantyBillService extends IBaseService<WarrantyBill> {
	void delete(Long[] itemsIds);
}
