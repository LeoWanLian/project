package com.bug.crm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bug.crm.domain.SystemLog;
import com.bug.crm.query.SystemLogQuery;
import com.bug.crm.query.PageList;
import com.bug.crm.service.ISystemLogService;
import com.bug.crm.util.AjaxResult;

/**
 * 部门控制层
 * 
 * @author leowan
 */
@Controller
@RequestMapping("/systemLog")
public class SystemLogController {
	@Autowired
	ISystemLogService systemLogService;

	// 一个方法显示页面,其他都返回json
	@RequestMapping("/list")
	public String list() {
		return "systemLog";
	}

	@RequestMapping("/json")
	@ResponseBody
	public PageList json(SystemLogQuery baseQuery) {
		return systemLogService.findByQuery(baseQuery);
	}

	// 保存方法
	@RequestMapping("/save")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult save(SystemLog systemLog) {
		try {
			if (systemLog.getId() != null) {
				systemLogService.update(systemLog);
			} else {
				systemLogService.save(systemLog);
			}
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("保存异常:" + e.getMessage());
		}
	}

	@RequestMapping("/delete")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult delete(Long id) {
		try {
			systemLogService.delete(id);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}

}
