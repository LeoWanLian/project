package com.bug.crm.service;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.bug.crm.domain.Customer;
import com.bug.crm.query.CustomerQuery;

/**
 * 客户信息管理
 * 
 * @author leowan
 */
public interface ICustomerService extends IBaseService<Customer> {
	/**
	 * 将客户放入资源池
	 */
	void putInPool(Long[] str2);
	/**
	 * 将资源池客户转为客户
	 */
	void removePool(Long[] str2);
	
	/**
	 * 下载当前数据excel 文件
	 * @param customerQuery 
	 */
	InputStream downloadExcel(CustomerQuery customerQuery);
	
	/**
	 * 导入Excel数据
	 */
	void upload(MultipartFile upload);
	
	/**
	 * 制作报表的数据
	 * @return
	 */
	List<Map<String,Long>> highChart();
}
