package com.bug.crm.service;

import org.springframework.transaction.annotation.Transactional;

import com.bug.crm.domain.Employee;

/**
 * 员工管理service层接口
 *
 */
public interface IEmployeeService extends IBaseService<Employee> {
	
	
	
	
	@Transactional
	void leave(Long id);

}
