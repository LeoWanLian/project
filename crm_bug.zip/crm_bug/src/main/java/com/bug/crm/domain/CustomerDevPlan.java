package com.bug.crm.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 
 * @author Administrator 日期:2018年3月29日 类描述:客户发展计划
 */
public class CustomerDevPlan extends BaseDomain {
	private Date planTime;// 计划时间
	private String planSubject;// 计划主题
	private String planDetails;// 计划内容
	private SystemDictionaryItem planType;// 计划实施方式---计划采用如电话、邀约上门等
	private PotentialCustomer potentialCustomer;// 潜在客户对象
	private Employee inputUser;// 创建人 ---自动填入当前登录用户，用户不可更改
	private Date inputTime;// 创建时间当前系统时间

	@JsonFormat(pattern="yyyy-MM-dd ",timezone="GMT+8")
	public Date getPlanTime() {
		return planTime;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd ")
	public void setPlanTime(Date planTime) {
		this.planTime = planTime;
	}

	public String getPlanDetails() {
		return planDetails;
	}

	public void setPlanDetails(String planDetails) {
		this.planDetails = planDetails;
	}

	public SystemDictionaryItem getPlanType() {
		return planType;
	}

	public void setPlanType(SystemDictionaryItem planType) {
		this.planType = planType;
	}

	public PotentialCustomer getPotentialCustomer() {
		return potentialCustomer;
	}

	public void setPotentialCustomer(PotentialCustomer potentialCustomer) {
		this.potentialCustomer = potentialCustomer;
	}

	public String getPlanSubject() {
		return planSubject;
	}

	public void setPlanSubject(String planSubject) {
		this.planSubject = planSubject;
	}

	public Employee getInputUser() {
		return inputUser;
	}

	public void setInputUser(Employee inputUser) {
		this.inputUser = inputUser;
	}

	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")

	public Date getInputTime() {
		return inputTime;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public void setInputTime(Date inputTime) {
		this.inputTime = inputTime;
	}

	@Override
	public String toString() {
		return "CustomerDevPlan [planTime=" + planTime + "]";
	}

}
