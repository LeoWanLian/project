package com.bug.crm.query;

public class SystemDictionaryItemQuery extends BaseQuery {
	private Long parentId;

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

}
