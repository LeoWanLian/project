package com.bug.crm.mapper;

import com.bug.crm.domain.ContractItem;

/**
 * 合同管理明细的mapper
 * 
 * @author leowan
 */
public interface ContractItemMapper extends BaseMapper<ContractItem> {

}
