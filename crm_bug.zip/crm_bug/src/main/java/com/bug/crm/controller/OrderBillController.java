package com.bug.crm.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bug.crm.domain.OrderBill;
import com.bug.crm.query.OrderBillQuery;
import com.bug.crm.query.PageList;
import com.bug.crm.service.ICustomerService;
import com.bug.crm.service.IEmployeeService;
import com.bug.crm.service.IOrderBillService;
import com.bug.crm.util.AjaxResult;

/**
 * 定金订单控制层
 * 
 * @author leowan
 */
@Controller
@RequestMapping("/orderBill")
public class OrderBillController {
	@Autowired
	IOrderBillService orderBillService;
	@Autowired
	ICustomerService customerService;
	@Autowired
	IEmployeeService employeeService;

	// 一个方法显示页面,其他都返回json
	@RequestMapping("/list")
	public String list(Model model) {
		model.addAttribute("orderBills", orderBillService.getAll());
		return "orderBill";
	}

	@RequestMapping("/json")
	@ResponseBody
	public PageList json(OrderBillQuery baseQuery) {
		return orderBillService.findByQuery(baseQuery);
	}

	// 保存方法
	@RequestMapping("/save")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult save(OrderBill orderBill) {
		try {
			if (orderBill.getId() != null) {//编辑
				if("".equals(orderBill.getSn())||orderBill.getSn()==null){
					orderBill.setSn("sn-"+new SimpleDateFormat("yyyyMMddHHmmSSS").format(new Date()));
				}
				orderBillService.update(orderBill);
			} else {//新增
				orderBill.setSignTime(new Date());
				orderBill.setSn("sn-"+new SimpleDateFormat("yyyyMMddHHmmSSS").format(new Date()));
				orderBillService.save(orderBill);
			}
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("保存异常:" + e.getMessage());
		}
	}

	@RequestMapping("/delete")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult delete(String ids) {
		try {
			//截取字符串
			String[] strArr = ids.split(",");
			//将前台传过来的字符串转成long数组
	        Long[] str2 = new Long[strArr.length];
	        for (int i = 0; i < strArr.length; i++) {
	            str2[i] = Long.valueOf(strArr[i]);
	        }
			//循环删除
			for (Long long1 : str2) {
				orderBillService.delete(long1);
			}
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}
	
	@RequestMapping("/getCustomerData")
	@ResponseBody
	// 下拉选择客户信息
	public Object getCustomerData() {
		return customerService.getAll();
	}
	
	@RequestMapping("/getSellerrData")
	@ResponseBody
	// 下拉选择销售人员信息
	public Object getSellerrData() {
		return employeeService.getAll();
	}
}
