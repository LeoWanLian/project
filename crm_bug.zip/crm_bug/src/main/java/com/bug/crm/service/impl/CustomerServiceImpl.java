package com.bug.crm.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.bug.crm.controller.UserContext;
import com.bug.crm.domain.Customer;
import com.bug.crm.mapper.CustomerMapper;
import com.bug.crm.query.CustomerQuery;
import com.bug.crm.service.ICustomerService;

/**
 * 子类部门管理的service层实现,必须有@service注解 客户信息管理
 */
@Service
public class CustomerServiceImpl extends BaseServiceImpl<Customer> implements ICustomerService {
	@Autowired
	private CustomerMapper customerMapper;

	@Transactional
	@Override
	public void putInPool(Long[] str2) {
		customerMapper.putInPool(str2);
	}

	@Transactional
	@Override
	public void removePool(Long[] str2) {
		customerMapper.removePool(str2);
	}

	@Override
	public InputStream downloadExcel(CustomerQuery customerQuery) {
		List<Customer> Customers = customerMapper.findLimitByQuery(customerQuery);
		// 创建客户信息集合
		List<String[]> data = new ArrayList<String[]>();
		// 创建表头数组
		String[] heat = { "编号", "姓名", "年龄", "性别", "电话", "职业", "收入水平", "客户来源", "营销人员", "录入员", "录入时间", "状态" };
		int i = 0;
		//时间格式
		SimpleDateFormat simpleDateFormat = new  SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		// 将员工信息添加到数组集合中
		for (Customer customer : Customers) {
			String[] str = new String[heat.length];
			str[0] = i++ + "";
			str[1] = customer.getName();
			str[2] = customer.getAge() == null ? "" : customer.getAge().toString();
			str[3] = customer.getGender() == true ? "男" : "女";
			str[4] = customer.getTel();
			str[5] = customer.getJob() == null ? "" : customer.getJob().getName();
			str[6] = customer.getSalaryLevel() == null ? "" : customer.getSalaryLevel().getName();
			str[7] = customer.getCustomerSource() == null ? "" : customer.getCustomerSource().getName();
			str[8] = customer.getSeller() == null ? "" : customer.getSeller().getUsername();
			str[9] = customer.getInputUser() == null ? "" : customer.getInputUser().getUsername();
			str[10] = customer.getInputTime() == null ? "" :simpleDateFormat.format(customer.getInputTime()).toString();
			str[11] = customer.getState() == -1 ? "资源池状态" : "正常";
			data.add(str);
		}
		return downLoad(heat, data);

	}

	private InputStream downLoad(String[] heat, List<String[]> data) {
		// 创建一个对象内存
		SXSSFWorkbook wb = new SXSSFWorkbook();
		// 创建一个表
		Sheet sh = wb.createSheet();
		// 创建表头
		Row createRow = sh.createRow(0);
		// 插入表头
		for (int column = 0; column < heat.length; column++) {
			Cell cell = createRow.createCell(column);
			cell.setCellValue(heat[column]);
		}
		// 插入数据
		for (int rownum = 1; rownum <= data.size(); rownum++) {
			String[] strings = data.get(rownum - 1);
			// 创建表里面的行
			Row row = sh.createRow(rownum);
			for (int cellnum = 0; cellnum < heat.length; cellnum++) {
				// 处理单元格
				Cell cell = row.createCell(cellnum);
				cell.setCellValue(strings[cellnum]);
			}
		}

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		try {
			wb.write(out);
		} catch (IOException e) {
			e.printStackTrace();
		}
		wb.dispose();
		return new ByteArrayInputStream(out.toByteArray());
	}

	/**
	 * 导入Excel数据
	 */
	@Override
	@Transactional
	public void upload(MultipartFile upload) {
		List<String[]> list=null; 
		try {
			list = importXlsx(upload);
		} catch (IOException e) {
			e.printStackTrace();
		}
		for (String[] strings : list) {
						
			Customer customer = new Customer();
			customer.setName(strings[0]);//姓名
			customer.setAge(Integer.valueOf(strings[1]));//年龄
			customer.setGender("男".equals(strings[2])?true:false);//性别
			customer.setTel(strings[3]);//电话
			customer.setInputTime(new Date());//录入时间
			customer.setInputUser(UserContext.getLoginUser());//录入人
			super.save(customer);
			
		}
		
	}

	// 将Excel文件转换为数组
	private List<String[]> importXlsx(MultipartFile upload) throws IOException {
		// 准备返回的List
		List<String[]> list = new ArrayList<String[]>();
		// 准备要读取的文件流
		InputStream is =upload.getInputStream();// 解析的是上传的xlsx文件
		// 创建读取对象
		Workbook workbook = new XSSFWorkbook(is);
		// 固定获取读取的第一个sheet表
		Sheet sheet = workbook.getSheetAt(0);
		// 获取表里面有多少行
		int num = sheet.getLastRowNum();
		// 遍历行
		for (int i = 0; i < num; i++) {
			// 获取行对象
			Row row = sheet.getRow(i + 1);// 按照我们的规定上传的xlsx文件的包含表头的，排除表头i = 1
			// 获取行里面有多少列
			short cellNum = row.getLastCellNum();
			// 实例化数组
			String[] strings = new String[cellNum];
			for (int j = 0; j < cellNum; j++) {
				// 获取格子对象
				Cell cell = row.getCell(j);
				// 获格格子对象里面的数据
				if(Cell.CELL_TYPE_NUMERIC == cell.getCellType()){//如果表中未数字类型
					strings[j] =String.valueOf((int)cell.getNumericCellValue());
				}else{
					
					strings[j] = cell.getStringCellValue();
				}
			}
			// 添加数据到集合
			list.add(strings);
		}
		return list;
	}
	
	/**
	 * 制作报表的数据
	 * @return
	 */
	@Override
	public List<Map<String,Long>> highChart() {
		return customerMapper.highChart();
	}
}
