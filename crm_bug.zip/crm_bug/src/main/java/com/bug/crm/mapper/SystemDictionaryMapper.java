package com.bug.crm.mapper;

import com.bug.crm.domain.SystemDictionary;

/**
 *	部门管理的mapper 
 *
 */
public interface SystemDictionaryMapper extends BaseMapper<SystemDictionary>{
	
}
