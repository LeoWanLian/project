package com.bug.crm.query;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class CustomerDevPlanQuery extends BaseQuery {

	// 计划方式
	private Integer planTpyeId;
	// 潜在客户
	private Integer potentialCustomerId;
	// 录入员
	private Integer inputUserId;
	// 起始时间
	private Date beginTime;
	// 结束时间
	private Date endTime;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date getBeginTime() {
		return beginTime;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date getEndTime() {
		return endTime;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Integer getPlanTpyeId() {
		return planTpyeId;
	}

	public void setPlanTpyeId(Integer planTpyeId) {
		this.planTpyeId = planTpyeId;
	}

	public Integer getPotentialCustomerId() {
		return potentialCustomerId;
	}

	public void setPotentialCustomerId(Integer potentialCustomerId) {
		this.potentialCustomerId = potentialCustomerId;
	}

	public Integer getInputUserId() {
		return inputUserId;
	}

	public void setInputUserId(Integer inputUserId) {
		this.inputUserId = inputUserId;
	}
	
}
