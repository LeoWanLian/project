package com.bug.crm.query;

public class ContractItemQuery extends BaseQuery {
	private Long contractId;

	public Long getContractId() {
		return contractId;
	}

	public void setContractId(Long contractId) {
		this.contractId = contractId;
	}

	@Override
	public String toString() {
		return "ContractItemQuery [contractId=" + contractId + "]";
	}
	
	

}
