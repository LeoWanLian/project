package com.bug.crm.service;

import com.bug.crm.domain.SystemDictionary;

/**
 * 部门管理service层接口
 *
 */
public interface ISystemDictionaryService extends IBaseService<SystemDictionary> {
	
}
