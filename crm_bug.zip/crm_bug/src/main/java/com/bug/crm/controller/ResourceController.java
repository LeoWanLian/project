package com.bug.crm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bug.crm.domain.Resource;
import com.bug.crm.query.ResourceQuery;
import com.bug.crm.query.PageList;
import com.bug.crm.service.IResourceService;
import com.bug.crm.util.AjaxResult;

/**
 * 部门控制层
 * 
 * @author leowan
 */
@Controller
@RequestMapping("/resource")
public class ResourceController {
	@Autowired
	IResourceService resourceService;

	// 一个方法显示页面,其他都返回json
	@RequestMapping("/list")
	public String list() {
		return "resource";
	}

	@RequestMapping("/json")
	@ResponseBody
	public PageList json(ResourceQuery baseQuery) {
		return resourceService.findByQuery(baseQuery);
	}

	// 保存方法
	@RequestMapping("/save")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult save(Resource resource) {
		try {
			if (resource.getId() != null) {
				resourceService.update(resource);
			} else {
				resourceService.save(resource);
			}
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("保存异常:" + e.getMessage());
		}
	}

	@RequestMapping("/delete")
	@ResponseBody
	// {"success":true,"message":"xxx"}
	public AjaxResult delete(Long id) {
		try {
			resourceService.delete(id);
			return new AjaxResult();
		} catch (Exception e) {
			e.printStackTrace();
			return new AjaxResult("删除异常:" + e.getMessage());
		}
	}

}
