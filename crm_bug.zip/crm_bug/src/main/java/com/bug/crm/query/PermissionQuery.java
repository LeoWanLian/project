package com.bug.crm.query;

public class PermissionQuery extends BaseQuery{

}
