package com.bug.crm.service;

import java.util.List;

import com.bug.crm.domain.CustomerDevPlan;
import com.bug.crm.domain.SystemDictionaryItem;

/**
 * 
 * @author leowan
 * 日期:2018年3月29日
 * 类描述:（潜在）客户开发计划
 */
public interface ICustomerDevPlanService extends IBaseService<CustomerDevPlan> {
	
}
