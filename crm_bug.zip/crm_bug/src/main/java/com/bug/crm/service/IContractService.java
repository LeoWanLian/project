package com.bug.crm.service;

import com.bug.crm.domain.Contract;

/**
 * 
 * @author leowan
 * 日期:2018年3月29日
 * 类描述:定金订单service层接口
 */
public interface IContractService extends IBaseService<Contract> {
	
	void delete(Long[] itemsIds);
}
